<?php
function cur_url()
{
    $protocol = strpos(strtolower($_SERVER['SERVER_PROTOCOL']), 'https') === FALSE ? 'http' : 'https';
    $host = $_SERVER['HTTP_HOST'];
    $script = $_SERVER['SCRIPT_NAME'];
    $params = $_SERVER['QUERY_STRING'];
    $currentUrl = $protocol . '://' . $host . $script . '?' . $params;
    return $currentUrl;
}

function cur_server()
{
    $protocol = strpos(strtolower($_SERVER['SERVER_PROTOCOL']), 'https') === FALSE ? 'http' : 'https';
    $host = $_SERVER['HTTP_HOST'];
    $script = $_SERVER['SCRIPT_NAME'];
    $currentUrl = $protocol . '://' . $host . $script;
    $currentUrl = explode('/', $currentUrl);
    unset($currentUrl[count($currentUrl) - 1]);
    $currentUrl = implode('/', $currentUrl) . '/';
    return $currentUrl;
}

function cur_script()
{
    return basename($_SERVER['PHP_SELF']);
}

function truncate($input, $maxWords, $maxChars)
{
    $words = preg_split('/\s+/', $input);
    $words = array_slice($words, 0, $maxWords);
    $words = array_reverse($words);

    $chars = 0;
    $truncated = array();

    while (count($words) > 0) {
        $fragment = trim(array_pop($words));
        $chars += strlen($fragment);

        if ($chars > $maxChars) break;

        $truncated[] = $fragment;
    }

    $result = implode($truncated, ' ');

    return $result . ($input == $result ? '' : '...');
}

function get_ip()
{
    if (!empty($_SERVER['HTTP_CLIENT_IP'])) {
        $ip = $_SERVER['HTTP_CLIENT_IP'];
    } elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
        $ip = $_SERVER['HTTP_X_FORWARDED_FOR'];
    } else {
        $ip = $_SERVER['REMOTE_ADDR'];
    }
    return $ip;
}

function DateConversionDB($tmpDate)
{
    $tmpDate = explode('/', $tmpDate);
    $time = mktime(0, 0, 0, $tmpDate[0], $tmpDate[1], $tmpDate[2]);
    $mysqldate = date('Y-m-d H:i:s', $time);
    return $mysqldate;
}

function ReverseDateConversionDB($tmpDate)
{
    $tmpDate = explode('/', $tmpDate);
    $time = mktime(0, 0, 0, $tmpDate[0], $tmpDate[1], $tmpDate[2]);
    $mysqldate = date('Y-m-d H:i:s', $time);
    return $mysqldate;
}

function mysql_real_escape_string_undo($str)
{
    return str_replace("rn", "", str_replace("\\", "", htmlspecialchars_decode(nl2br($str), ENT_COMPAT | ENT_XHTML)));
}


function createThumbnail($image_name, $new_width, $new_height, $uploadDir, $moveToDir)
{
    $path = $uploadDir . '/' . $image_name;
    $mime = getimagesize($path);

    if ($mime['mime'] == 'image/png') {
        $src_img = imagecreatefrompng($path);
    }
    if ($mime['mime'] == 'image/jpg') {
        $src_img = imagecreatefromjpeg($path);
    }
    if ($mime['mime'] == 'image/jpeg') {
        $src_img = imagecreatefromjpeg($path);
    }
    if ($mime['mime'] == 'image/pjpeg') {
        $src_img = imagecreatefromjpeg($path);
    }

    $old_x = imageSX($src_img);
    $old_y = imageSY($src_img);

    if ($old_x > $old_y) {
        $thumb_w = $new_width;
        $thumb_h = $old_y * ($new_height / $old_x);
    }

    if ($old_x < $old_y) {
        $thumb_w = $old_x * ($new_width / $old_y);
        $thumb_h = $new_height;
    }

    if ($old_x == $old_y) {
        $thumb_w = $new_width;
        $thumb_h = $new_height;
    }

    $dst_img = ImageCreateTrueColor($thumb_w, $thumb_h);

    imagecopyresampled($dst_img, $src_img, 0, 0, 0, 0, $thumb_w, $thumb_h, $old_x, $old_y);


    // New save location
    $new_thumb_loc = $moveToDir . $image_name;

    if ($mime['mime'] == 'image/png') {
        $result = imagepng($dst_img, $new_thumb_loc, 8);
    }
    if ($mime['mime'] == 'image/jpg') {
        $result = imagejpeg($dst_img, $new_thumb_loc, 80);
    }
    if ($mime['mime'] == 'image/jpeg') {
        $result = imagejpeg($dst_img, $new_thumb_loc, 80);
    }
    if ($mime['mime'] == 'image/pjpeg') {
        $result = imagejpeg($dst_img, $new_thumb_loc, 80);
    }

    imagedestroy($dst_img);
    imagedestroy($src_img);

    return $result;
}


function get_insert_id()
{
    $q = mysql_query("SELECT LAST_INSERT_ID()");
    if ($q) {
        $data = mysql_fetch_assoc($q);
        return $data['LAST_INSERT_ID()'];
    } else {
        return false;
    }
}


function mysqli_li_id($con = false)
{
    if ($con) {
        $q = mysqli_query($con, "SELECT LAST_INSERT_ID() AS last");
        if ($q) {
            $data = mysqli_fetch_assoc($q);
            return $data['last'];
        } else {
            return false;
        }
    } else {
        return false;
    }
}


function Slug($string)
{
    return strtolower(trim(preg_replace('~[^0-9a-z]+~i', '-', html_entity_decode(preg_replace('~&([a-z]{1,2})(?:acute|cedil|circ|grave|lig|orn|ring|slash|th|tilde|uml);~i', '$1', htmlentities($string, ENT_QUOTES, 'UTF-8')), ENT_QUOTES, 'UTF-8')), '-'));
}

function notify($msg = false)
{
    if ($msg != false) {
        $_SESSION['msg'] = $msg;
        return true;
    } else {
        unset($_SESSION['msg']);
        return false;
    }
}

function jsGoBack()
{
    ?>
    <script>
        history.go(-1);
    </script>
    <?php
}

function phpGoBack($die = false)
{
    header("Location: " . $_SERVER['HTTP_REFERER']);
    if ($die) {
        die();
    }
}


function go2($url = false)
{
    if ($url) {
        header("Location: " . $url);
    } else {
        return "<strong>ERROR:</strong> Paremeter 'URL' is missing";
    }
}


function str_2_p($str = '')
{
    $str = stripslashes($str);
    $str = str_ireplace("rn", "", $str);
    $str = nl2br($str);

    return $str;
}

function compress_image($src, $dest, $quality)
{
    $info = getimagesize($src);


    if ($info['mime'] == 'image/jpeg') {
        $image = imagecreatefromjpeg($src);
        imagejpeg($image, $dest, $quality);
    } elseif ($info['mime'] == 'image/gif') {
        $image = imagecreatefromgif($src);
        imagegif($image, $dest);
    } elseif ($info['mime'] == 'image/png') {

        $image = imagecreatefrompng($src);
        imagepng($image, $dest, $quality);
    } else {
        die('Unknown image file format');
    }

    return $dest;
}

//usage
//$compressed = compress_image('Ban2.png', 'destination.png', 4); 

//On Error
//ini_set('memory_limit', '-1');
//ini_set('post_max_size', '1000M');
//ini_set('upload_max_filesize', '1000M');


function make_thumb($src, $dest, $desired_width)
{
    $file_ex = explode(".", $src);
    $ext = end($file_ex);

    if ($ext != "png" and $ext != "PNG") {

        $source_image = imagecreatefromjpeg($src);
        $width = imagesx($source_image);
        $height = imagesy($source_image);

        $desired_height = floor($height * ($desired_width / $width));

        $virtual_image = imagecreatetruecolor($desired_width, $desired_height);

        imagecopyresampled($virtual_image, $source_image, 0, 0, 0, 0, $desired_width, $desired_height, $width, $height);

        imagejpeg($virtual_image, $dest);
    } else {

        $source_image = imagecreatefrompng($src);
        $width = imagesx($source_image);
        $height = imagesy($source_image);

        $desired_height = floor($height * ($desired_width / $width));

        $newImg = imagecreatetruecolor($desired_width, $desired_height);
        imagealphablending($newImg, false);
        imagesavealpha($newImg, true);
        $transparent = imagecolorallocatealpha($newImg, 255, 255, 255, 127);
        imagefilledrectangle($newImg, 0, 0, $desired_width, $desired_height, $transparent);
        imagecopyresampled($newImg, $source_image, 0, 0, 0, 0, $desired_width, $desired_height,
            $width, $height);

        imagepng($newImg, $dest);
    }
}

//usage
//make_thumb('images/image.jpg', 'images/thumb.jpg', 200);

function trim_image($src, $dest)
{
    $img = imagecreatefromjpeg($src);

    $b_top = 0;
    $b_btm = 0;
    $b_lft = 0;
    $b_rt = 0;

    for (; $b_top < imagesy($img); ++$b_top) {
        for ($x = 0; $x < imagesx($img); ++$x) {
            if (imagecolorat($img, $x, $b_top) != 0xFFFFFF) {
                break 2;
            }
        }
    }

    for (; $b_btm < imagesy($img); ++$b_btm) {
        for ($x = 0; $x < imagesx($img); ++$x) {
            if (imagecolorat($img, $x, imagesy($img) - $b_btm - 1) != 0xFFFFFF) {
                break 2;
            }
        }
    }

    for (; $b_lft < imagesx($img); ++$b_lft) {
        for ($y = 0; $y < imagesy($img); ++$y) {
            if (imagecolorat($img, $b_lft, $y) != 0xFFFFFF) {
                break 2;
            }
        }
    }

    for (; $b_rt < imagesx($img); ++$b_rt) {
        for ($y = 0; $y < imagesy($img); ++$y) {
            if (imagecolorat($img, imagesx($img) - $b_rt - 1, $y) != 0xFFFFFF) {
                break 2;
            }
        }
    }

    $newimg = imagecreatetruecolor(imagesx($img) - ($b_lft + $b_rt), imagesy($img) - ($b_top + $b_btm));

    imagecopy($newimg, $img, 0, 0, $b_lft, $b_top, imagesx($newimg), imagesy($newimg));

    imagejpeg($newimg, $dest, 100);
}


function watermark_image($mark, $image)
{
    $stamp = imagecreatefrompng($mark);
    $im = imagecreatefromjpeg($image);

    $marge_right = 10;
    $marge_bottom = 10;
    $sx = imagesx($stamp);
    $sy = imagesy($stamp);

    //imagecopy($im, $stamp, ((imagesx($im) - $sx - $marge_right)/100*50), ((imagesy($im) - $sy - $marge_bottom)/100*50), 0, 0, imagesx($stamp), imagesy($stamp));
    imagecopy($im, $stamp, imagesx($im) - $sx - $marge_right, imagesy($im) - $sy - $marge_bottom, 0, 0, imagesx($stamp), imagesy($stamp));

    imagepng($im, $image, 9);
}

function watermark_text($img, $text)
{
    $chk_img_arr = explode(".", $img);
    $ext = end($chk_img_arr);

    if ($ext != "png" || $ext != "PNG") {
        $my_img = imagecreatefromjpeg($img);
    } else {
        $my_img = imagecreatefrompng($img);
    }

    $water_mark_text_2 = $text;
    $font_path = "../css/font/Calibri_Bold.ttf";
    list($owidth, $oheight) = getimagesize($img);
    $width = imagesx($my_img);
    $height = imagesy($my_img);
    $font_size = ($width / 100) * 3.5;
    $shadow1_size = ($width / 100) * 3.5;
    $shadow2_size = ($width / 100) * 3.5;


    $txt_x = ($width / 100) * 4;

    $txt_y = ($height / 100) * 95;

    $shadow1_x = ($width / 100) * 3.9;

    $shadow1_y = ($height / 100) * 94.9;

    $shadow2_x = ($width / 100) * 4.1;

    $shadow2_y = ($height / 100) * 95.1;

    $image = imagecreatetruecolor($width, $height);

    if ($ext != "png" || $ext != "PNG") {
        $image_src = imagecreatefromjpeg($img);
    } else {
        $image_src = imagecreatefrompng($img);
    }

    imagecopyresampled($image, $image_src, 0, 0, 0, 0, $width, $height, $owidth, $oheight);
    $txt_color = imagecolorallocate($image, 255, 255, 255);
    $shadow_color = imagecolorallocatealpha($image, 0, 0, 0, 0);
    // imagettftext($image, $font_size, 0, 30, 190, $black, $font_path, $water_mark_text_1);
    imagettftext($image, $shadow1_size, 0, $shadow1_x, $shadow1_y, $shadow_color, $font_path, $water_mark_text_2);
    imagettftext($image, $shadow2_size, 0, $shadow2_x, $shadow2_y, $shadow_color, $font_path, $water_mark_text_2);
    imagettftext($image, $font_size, 0, $txt_x, $txt_y, $txt_color, $font_path, $water_mark_text_2);
    if ($ext != "png" || $ext != "PNG") {
        imagejpeg($image, $img, 100);
    } else {
        imagepng($image, $img, 9);
    }

    imagedestroy($image);
}

function sec2timefull($timestamp, $full = true)
{
    $how_log_ago = '';
    $seconds = time() - $timestamp;
    $minutes = (int)($seconds / 60);
    $hours = (int)($minutes / 60);
    $days = (int)($hours / 24);
    if ($days >= 1) {
        $how_log_ago = $days . ($full ? ' day' : '') . ($days != 1 ? 's' : '');
    } else if ($hours >= 1) {
        $how_log_ago = $hours . ($full ? ' hour' : '') . ($hours != 1 ? 's' : '');
    } else if ($minutes >= 1) {
        $how_log_ago = $minutes . ($full ? ' min' : '') . ($minutes != 1 ? 's' : '');
    } else {
        $how_log_ago = $seconds . ($full ? ' sec' : '') . ($seconds != 1 ? 's' : '');
    }
    return $how_log_ago;
}

function create_html($tag_name = 'a', $attrs = false, $self_close = false, $tag_data = '')
{
    $data = '<' . $tag_name;
    if ($attrs !== false) {
        foreach ($attrs as $attr => $val) {
            $data .= ' ' . $attr . '="' . $val . '"';
        }
    }

    if ($tag_name == "select") {
        $ret_data = '<option value="0">' . $attrs['placeholder'] . '</option>';
        foreach ($tag_data as $opt => $val) {
            if (strpos($val, '|s')) {
                $val = explode('|', $val);
                $ret_data .= '<option value="' . $val[0] . '" selected>' . $opt . '</option>';
            } else {
                $ret_data .= '<option value="' . $val . '">' . $opt . '</option>';
            }
        }
    } else {
        $ret_data = $tag_data;
    }

    if ($self_close) {
        $data .= ' />';
    } else {
        $data .= '>' . $ret_data . '</' . $tag_name . '>';
    }
    return $data;
}


function chk_req($REQ_VAR = false, $strlen_chk = false)
{
    if ($var) {
        if (isset($_REQUEST[$var])) {
            if ($strlen_chk) {
                if (strlen($_REQUEST[$var]) > 0) {
                    return true;
                } else {
                    return false;
                }
            } else {
                return true;
            }
        } else {
            return false;
        }
    } else {
        return false;
    }
}

function str_db_filter($value = '')
{
    $newVal = htmlspecialchars($newVal);
    $newVal = mysql_real_escape_string($newVal);
    return $newVal;
}

function str_idb_filter($link, $value = '')
{
    $newVal = htmlspecialchars($newVal);
    $newVal = mysqli_real_escape_string($link, $newVal);
    return $newVal;
}

function remove_querystring_var($url, $key)
{
    $url = preg_replace('/(.*)(?|&)' . $key . '=[^&]+?(&)(.*)/i', '$1$2$4', $url . '&');
    $url = substr($url, 0, -1);
    return $url;
}

function remove_from_query_string($needle)
{
    $query_string = $_SERVER['QUERY_STRING']; // Work on a seperate copy and preserve the original for now
    $query_string = preg_replace("/\&" . $needle . "=[a-zA-Z0-9].*?(\&|$)/", '', $query_string);
    $query_string = preg_replace("/(&)+/", "", $query_string); // Supposed to pull out all repeating &s, however it allows 2 in a row(&&). Good enough for now
    return $query_string;
}

function chk_strlen_none($str, $none = false)
{
    if ($none) {
        $ret = (strlen(trim($str)) > 0 ? $str : $none);
    } else {
        $ret = (strlen(trim($str)) > 0 ? $str : false);
    }
    return $ret;
}

function get_field_data($type = "sql", $con = false, $tbl, $field, $where)
{
    switch ($type) {
        case "sql":
            $data = mysql_fetch_array(mysql_query("SELECT " . $field . " FROM " . $tbl . " " . $where));
            return $data;
            break;
        case "sqli":
            $data = mysqli_fetch_array(mysqli_query($con, "SELECT " . $field . " FROM " . $tbl . " " . $where));
            return $data;
            break;
        default:
            return "Invalid SQL Type";

    }
}

if (!function_exists('show_404')) {
    function show_404()
    {
        go2(cur_server() . "error/404");
    }
}

function mysql_escstr($str = '', $con = false, $type = 'n')
{

    if (strlen(trim($str)) > 0) {
        if ($type == 'n') {
            if ($con) {
                return mysql_real_escape_string($str, $con);
            } else {
                return mysql_real_escape_string($str);
            }
        } elseif ($type == 'i') {
            if ($con) {
                return mysqli_real_escape_string($con, $str);
            } else {
                return false;
            }
        }
    } else {
        return false;
    }
}

function get_slug($tbl, $title, $id = false)
{
    $slug_temp = Slug($title);
    $sl_check = mysql_query("SELECT slug FROM " . $tbl . " WHERE slug = '" . $slug_temp . "'" . ($id ? " AND id != " . $id : ''));
    if (mysql_num_rows($sl_check) > 0) {
        $ok = 0;
        $si = 1;
        while ($ok == 0) {
            $this_slug = $slug_temp . "-" . $si;
            $siw_q = mysql_query("SELECT slug FROM " . $tbl . " WHERE slug = '" . $this_slug . "'" . ($id ? " AND id != " . $id : ''));
            if (mysql_num_rows($siw_q) == 0) {
                $slug = Slug($this_slug);
                $ok = 1;
                break;
            } else {
                $si++;
            }
        }

    } else {
        $slug = Slug($title);
    }
    return $slug;
}


function removeQueryStringParameter($url, $varname)
{
    $parsedUrl = parse_url($url);
    $query = array();

    if (isset($parsedUrl['query'])) {
        parse_str($parsedUrl['query'], $query);
        unset($query[$varname]);
    }

    $path = isset($parsedUrl['path']) ? $parsedUrl['path'] : '';
    $query = !empty($query) ? '?' . http_build_query($query) : '';

    return $path . $query;
}


function convertCurrency($from = "EUR", $to = "USD", $amount = 0)
{
    $cur = file_get_contents("https://query.yahooapis.com/v1/public/yql?q=select%20*%20from%20yahoo.finance.xchange%20where%20pair%20in%20(%22" . $from . $to . "%22)&format=json&diagnostics=true&env=store%3A%2F%2Fdatatables.org%2Falltableswithkeys&callback=");

    $cur = json_decode($cur);
    $rate = $cur->query->results->rate->Rate;
    $converted = $amount * $rate;
    return $converted;
}

function check_not_empty($s, $include_whitespace = false)
{
    if ($include_whitespace) {
        // make it so strings containing white space are treated as empty too
        $s = trim($s);
    }
    return (isset($s) && strlen($s)); // var is set and not an empty string ''
}

function array_preview($array = false)
{
    if ($array !== false) {
        echo "<pre>";
        print_r($array);
        echo "</pre>";
    }
}

function random_text($type = 'alnum', $length = 8)
{
    switch ($type) {
        case 'alnum':
            $pool = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
            break;
        case 'alpha':
            $pool = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
            break;
        case 'hexdec':
            $pool = '0123456789abcdef';
            break;
        case 'numeric':
            $pool = '0123456789';
            break;
        case 'nozero':
            $pool = '123456789';
            break;
        case 'distinct':
            $pool = '2345679ACDEFHJKLMNPRSTUVWXYZ';
            break;
        default:
            $pool = (string)$type;
            break;
    }


    $crypto_rand_secure = function ($min, $max) {
        $range = $max - $min;
        if ($range < 0) return $min; // not so random...
        $log = log($range, 2);
        $bytes = (int)($log / 8) + 1; // length in bytes
        $bits = (int)$log + 1; // length in bits
        $filter = (int)(1 << $bits) - 1; // set all lower bits to 1
        do {
            $rnd = hexdec(bin2hex(openssl_random_pseudo_bytes($bytes)));
            $rnd = $rnd & $filter; // discard irrelevant bits
        } while ($rnd >= $range);
        return $min + $rnd;
    };

    $token = "";
    $max = strlen($pool);
    for ($i = 0; $i < $length; $i++) {
        $token .= $pool[$crypto_rand_secure(0, $max)];
    }
    return $token;
}

if (!function_exists('get_value')) {
    function get_value($field = '', $default = '')
    {
        if (!isset($_POST[$field])) {
            if (count($_POST) === 0 AND $default !== '') {
                return $default;
            }
            return '';
        }

        return $_POST[$field];
    }
}

function getPrice($amount = 1,$discount = 0,$format = false){
    $r = ($amount - (($amount/100)*$discount));
    if($format){
        $r = number_format($r);
    }
    return $r;
}

function is_decimal( $val )
{
    return is_numeric( $val ) && floor( $val ) != $val;
}

function singularize ($params)
{
    if (is_string($params))
    {
        $word = $params;
    } else if (!$word = $params['word']) {
        return false;
    }
    $singular = array (
        '/(quiz)zes$/i' => '\\1',
        '/(matr)ices$/i' => '\\1ix',
        '/(vert|ind)ices$/i' => '\\1ex',
        '/^(ox)en/i' => '\\1',
        '/(alias|status)es$/i' => '\\1',
        '/([octop|vir])i$/i' => '\\1us',
        '/(cris|ax|test)es$/i' => '\\1is',
        '/(shoe)s$/i' => '\\1',
        '/(o)es$/i' => '\\1',
        '/(bus)es$/i' => '\\1',
        '/([m|l])ice$/i' => '\\1ouse',
        '/(x|ch|ss|sh)es$/i' => '\\1',
        '/(m)ovies$/i' => '\\1ovie',
        '/(s)eries$/i' => '\\1eries',
        '/([^aeiouy]|qu)ies$/i' => '\\1y',
        '/([lr])ves$/i' => '\\1f',
        '/(tive)s$/i' => '\\1',
        '/(hive)s$/i' => '\\1',
        '/([^f])ves$/i' => '\\1fe',
        '/(^analy)ses$/i' => '\\1sis',
        '/((a)naly|(b)a|(d)iagno|(p)arenthe|(p)rogno|(s)ynop|(t)he)ses$/i' => '\\1\\2sis',
        '/([ti])a$/i' => '\\1um',
        '/(n)ews$/i' => '\\1ews',
        '/s$/i' => ''
    );
    $irregular = array(
        'person' => 'people',
        'man' => 'men',
        'child' => 'children',
        'sex' => 'sexes',
        'move' => 'moves'
    );
    $ignore = array(
        'equipment',
        'information',
        'rice',
        'money',
        'species',
        'series',
        'fish',
        'sheep',
        'press',
        'sms',
    );
    $lower_word = strtolower($word);
    foreach ($ignore as $ignore_word)
    {
        if (substr($lower_word, (-1 * strlen($ignore_word))) == $ignore_word)
        {
            return $word;
        }
    }
    foreach ($irregular as $singular_word => $plural_word)
    {
        if (preg_match('/('.$plural_word.')$/i', $word, $arr))
        {
            return preg_replace('/('.$plural_word.')$/i', substr($arr[0],0,1).substr($singular_word,1), $word);
        }
    }
    foreach ($singular as $rule => $replacement)
    {
        if (preg_match($rule, $word))
        {
            return preg_replace($rule, $replacement, $word);
        }
    }
    return $word;
}


function httpPost($url, $data)
{
    $curl = curl_init($url);
    curl_setopt($curl, CURLOPT_POST, true);
    curl_setopt($curl, CURLOPT_POSTFIELDS, http_build_query($data));
    curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
    $response = curl_exec($curl);
    curl_close($curl);
    return $response;
}

function cleanString($String)
{
    $String = str_replace(array('á','à','â','ã','ª','ä'), "a", $String);
    $String = str_replace(array('Á','À','Â','Ã','Ä'), "a", $String);
    $String = str_replace(array('Í','Ì','Î','Ï'), "i", $String);
    $String = str_replace(array('í','ì','î','ï'), "i", $String);
    $String = str_replace(array('é','è','ê','ë'), "e", $String);
    $String = str_replace(array('É','È','Ê','Ë'), "e", $String);
    $String = str_replace(array('ó','ò','ô','õ','ö','º'), "o", $String);
    $String = str_replace(array('Ó','Ò','Ô','Õ','Ö'), "o", $String);
    $String = str_replace(array('ú','ù','û','ü'), "u", $String);
    $String = str_replace(array('Ú','Ù','Û','Ü'), "u", $String);
    $String = str_replace(array('[','^','´','`','¨','~',']'), "", $String);
    $String = str_replace("ç", "c", $String);
    $String = str_replace("Ç", "C", $String);
    $String = str_replace("ñ", "n", $String);
    $String = str_replace("Ñ", "N", $String);
    $String = str_replace("Ý", "Y", $String);
    $String = str_replace("ý", "y", $String);
    $String = str_replace("&aacute;", "a", $String);
    $String = str_replace("&Aacute;", "a", $String);
    $String = str_replace("&eacute;", "e", $String);
    $String = str_replace("&Eacute;", "e", $String);
    $String = str_replace("&iacute;", "i", $String);
    $String = str_replace("&Iacute;", "i", $String);
    $String = str_replace("&oacute;", "o", $String);
    $String = str_replace("&Oacute;", "o", $String);
    $String = str_replace("&uacute;", "u", $String);
    $String = str_replace("&Uacute;", "u", $String);
    return $String;
}

function country_code_to_country( $code ){
    $code = strtoupper($code);
    $country = '';
    if( $code == 'AF' ) $country = 'Afghanistan';
    if( $code == 'AX' ) $country = 'Aland Islands';
    if( $code == 'AL' ) $country = 'Albania';
    if( $code == 'DZ' ) $country = 'Algeria';
    if( $code == 'AS' ) $country = 'American Samoa';
    if( $code == 'AD' ) $country = 'Andorra';
    if( $code == 'AO' ) $country = 'Angola';
    if( $code == 'AI' ) $country = 'Anguilla';
    if( $code == 'AQ' ) $country = 'Antarctica';
    if( $code == 'AG' ) $country = 'Antigua and Barbuda';
    if( $code == 'AR' ) $country = 'Argentina';
    if( $code == 'AM' ) $country = 'Armenia';
    if( $code == 'AW' ) $country = 'Aruba';
    if( $code == 'AU' ) $country = 'Australia';
    if( $code == 'AT' ) $country = 'Austria';
    if( $code == 'AZ' ) $country = 'Azerbaijan';
    if( $code == 'BS' ) $country = 'Bahamas the';
    if( $code == 'BH' ) $country = 'Bahrain';
    if( $code == 'BD' ) $country = 'Bangladesh';
    if( $code == 'BB' ) $country = 'Barbados';
    if( $code == 'BY' ) $country = 'Belarus';
    if( $code == 'BE' ) $country = 'Belgium';
    if( $code == 'BZ' ) $country = 'Belize';
    if( $code == 'BJ' ) $country = 'Benin';
    if( $code == 'BM' ) $country = 'Bermuda';
    if( $code == 'BT' ) $country = 'Bhutan';
    if( $code == 'BO' ) $country = 'Bolivia';
    if( $code == 'BA' ) $country = 'Bosnia and Herzegovina';
    if( $code == 'BW' ) $country = 'Botswana';
    if( $code == 'BV' ) $country = 'Bouvet Island (Bouvetoya)';
    if( $code == 'BR' ) $country = 'Brazil';
    if( $code == 'IO' ) $country = 'British Indian Ocean Territory (Chagos Archipelago)';
    if( $code == 'VG' ) $country = 'British Virgin Islands';
    if( $code == 'BN' ) $country = 'Brunei Darussalam';
    if( $code == 'BG' ) $country = 'Bulgaria';
    if( $code == 'BF' ) $country = 'Burkina Faso';
    if( $code == 'BI' ) $country = 'Burundi';
    if( $code == 'KH' ) $country = 'Cambodia';
    if( $code == 'CM' ) $country = 'Cameroon';
    if( $code == 'CA' ) $country = 'Canada';
    if( $code == 'CV' ) $country = 'Cape Verde';
    if( $code == 'KY' ) $country = 'Cayman Islands';
    if( $code == 'CF' ) $country = 'Central African Republic';
    if( $code == 'TD' ) $country = 'Chad';
    if( $code == 'CL' ) $country = 'Chile';
    if( $code == 'CN' ) $country = 'China';
    if( $code == 'CX' ) $country = 'Christmas Island';
    if( $code == 'CC' ) $country = 'Cocos (Keeling) Islands';
    if( $code == 'CO' ) $country = 'Colombia';
    if( $code == 'KM' ) $country = 'Comoros the';
    if( $code == 'CD' ) $country = 'Congo';
    if( $code == 'CG' ) $country = 'Congo the';
    if( $code == 'CK' ) $country = 'Cook Islands';
    if( $code == 'CR' ) $country = 'Costa Rica';
    if( $code == 'CI' ) $country = 'Cote d\'Ivoire';
    if( $code == 'HR' ) $country = 'Croatia';
    if( $code == 'CU' ) $country = 'Cuba';
    if( $code == 'CY' ) $country = 'Cyprus';
    if( $code == 'CZ' ) $country = 'Czech Republic';
    if( $code == 'DK' ) $country = 'Denmark';
    if( $code == 'DJ' ) $country = 'Djibouti';
    if( $code == 'DM' ) $country = 'Dominica';
    if( $code == 'DO' ) $country = 'Dominican Republic';
    if( $code == 'EC' ) $country = 'Ecuador';
    if( $code == 'EG' ) $country = 'Egypt';
    if( $code == 'SV' ) $country = 'El Salvador';
    if( $code == 'GQ' ) $country = 'Equatorial Guinea';
    if( $code == 'ER' ) $country = 'Eritrea';
    if( $code == 'EE' ) $country = 'Estonia';
    if( $code == 'ET' ) $country = 'Ethiopia';
    if( $code == 'FO' ) $country = 'Faroe Islands';
    if( $code == 'FK' ) $country = 'Falkland Islands (Malvinas)';
    if( $code == 'FJ' ) $country = 'Fiji the Fiji Islands';
    if( $code == 'FI' ) $country = 'Finland';
    if( $code == 'FR' ) $country = 'France, French Republic';
    if( $code == 'GF' ) $country = 'French Guiana';
    if( $code == 'PF' ) $country = 'French Polynesia';
    if( $code == 'TF' ) $country = 'French Southern Territories';
    if( $code == 'GA' ) $country = 'Gabon';
    if( $code == 'GM' ) $country = 'Gambia the';
    if( $code == 'GE' ) $country = 'Georgia';
    if( $code == 'DE' ) $country = 'Germany';
    if( $code == 'GH' ) $country = 'Ghana';
    if( $code == 'GI' ) $country = 'Gibraltar';
    if( $code == 'GR' ) $country = 'Greece';
    if( $code == 'GL' ) $country = 'Greenland';
    if( $code == 'GD' ) $country = 'Grenada';
    if( $code == 'GP' ) $country = 'Guadeloupe';
    if( $code == 'GU' ) $country = 'Guam';
    if( $code == 'GT' ) $country = 'Guatemala';
    if( $code == 'GG' ) $country = 'Guernsey';
    if( $code == 'GN' ) $country = 'Guinea';
    if( $code == 'GW' ) $country = 'Guinea-Bissau';
    if( $code == 'GY' ) $country = 'Guyana';
    if( $code == 'HT' ) $country = 'Haiti';
    if( $code == 'HM' ) $country = 'Heard Island and McDonald Islands';
    if( $code == 'VA' ) $country = 'Holy See (Vatican City State)';
    if( $code == 'HN' ) $country = 'Honduras';
    if( $code == 'HK' ) $country = 'Hong Kong';
    if( $code == 'HU' ) $country = 'Hungary';
    if( $code == 'IS' ) $country = 'Iceland';
    if( $code == 'IN' ) $country = 'India';
    if( $code == 'ID' ) $country = 'Indonesia';
    if( $code == 'IR' ) $country = 'Iran';
    if( $code == 'IQ' ) $country = 'Iraq';
    if( $code == 'IE' ) $country = 'Ireland';
    if( $code == 'IM' ) $country = 'Isle of Man';
    if( $code == 'IL' ) $country = 'Israel';
    if( $code == 'IT' ) $country = 'Italy';
    if( $code == 'JM' ) $country = 'Jamaica';
    if( $code == 'JP' ) $country = 'Japan';
    if( $code == 'JE' ) $country = 'Jersey';
    if( $code == 'JO' ) $country = 'Jordan';
    if( $code == 'KZ' ) $country = 'Kazakhstan';
    if( $code == 'KE' ) $country = 'Kenya';
    if( $code == 'KI' ) $country = 'Kiribati';
    if( $code == 'KP' ) $country = 'Korea';
    if( $code == 'KR' ) $country = 'Korea';
    if( $code == 'KW' ) $country = 'Kuwait';
    if( $code == 'KG' ) $country = 'Kyrgyz Republic';
    if( $code == 'LA' ) $country = 'Lao';
    if( $code == 'LV' ) $country = 'Latvia';
    if( $code == 'LB' ) $country = 'Lebanon';
    if( $code == 'LS' ) $country = 'Lesotho';
    if( $code == 'LR' ) $country = 'Liberia';
    if( $code == 'LY' ) $country = 'Libyan Arab Jamahiriya';
    if( $code == 'LI' ) $country = 'Liechtenstein';
    if( $code == 'LT' ) $country = 'Lithuania';
    if( $code == 'LU' ) $country = 'Luxembourg';
    if( $code == 'MO' ) $country = 'Macao';
    if( $code == 'MK' ) $country = 'Macedonia';
    if( $code == 'MG' ) $country = 'Madagascar';
    if( $code == 'MW' ) $country = 'Malawi';
    if( $code == 'MY' ) $country = 'Malaysia';
    if( $code == 'MV' ) $country = 'Maldives';
    if( $code == 'ML' ) $country = 'Mali';
    if( $code == 'MT' ) $country = 'Malta';
    if( $code == 'MH' ) $country = 'Marshall Islands';
    if( $code == 'MQ' ) $country = 'Martinique';
    if( $code == 'MR' ) $country = 'Mauritania';
    if( $code == 'MU' ) $country = 'Mauritius';
    if( $code == 'YT' ) $country = 'Mayotte';
    if( $code == 'MX' ) $country = 'Mexico';
    if( $code == 'FM' ) $country = 'Micronesia';
    if( $code == 'MD' ) $country = 'Moldova';
    if( $code == 'MC' ) $country = 'Monaco';
    if( $code == 'MN' ) $country = 'Mongolia';
    if( $code == 'ME' ) $country = 'Montenegro';
    if( $code == 'MS' ) $country = 'Montserrat';
    if( $code == 'MA' ) $country = 'Morocco';
    if( $code == 'MZ' ) $country = 'Mozambique';
    if( $code == 'MM' ) $country = 'Myanmar';
    if( $code == 'NA' ) $country = 'Namibia';
    if( $code == 'NR' ) $country = 'Nauru';
    if( $code == 'NP' ) $country = 'Nepal';
    if( $code == 'AN' ) $country = 'Netherlands Antilles';
    if( $code == 'NL' ) $country = 'Netherlands the';
    if( $code == 'NC' ) $country = 'New Caledonia';
    if( $code == 'NZ' ) $country = 'New Zealand';
    if( $code == 'NI' ) $country = 'Nicaragua';
    if( $code == 'NE' ) $country = 'Niger';
    if( $code == 'NG' ) $country = 'Nigeria';
    if( $code == 'NU' ) $country = 'Niue';
    if( $code == 'NF' ) $country = 'Norfolk Island';
    if( $code == 'MP' ) $country = 'Northern Mariana Islands';
    if( $code == 'NO' ) $country = 'Norway';
    if( $code == 'OM' ) $country = 'Oman';
    if( $code == 'PK' ) $country = 'Pakistan';
    if( $code == 'PW' ) $country = 'Palau';
    if( $code == 'PS' ) $country = 'Palestinian Territory';
    if( $code == 'PA' ) $country = 'Panama';
    if( $code == 'PG' ) $country = 'Papua New Guinea';
    if( $code == 'PY' ) $country = 'Paraguay';
    if( $code == 'PE' ) $country = 'Peru';
    if( $code == 'PH' ) $country = 'Philippines';
    if( $code == 'PN' ) $country = 'Pitcairn Islands';
    if( $code == 'PL' ) $country = 'Poland';
    if( $code == 'PT' ) $country = 'Portugal, Portuguese Republic';
    if( $code == 'PR' ) $country = 'Puerto Rico';
    if( $code == 'QA' ) $country = 'Qatar';
    if( $code == 'RE' ) $country = 'Reunion';
    if( $code == 'RO' ) $country = 'Romania';
    if( $code == 'RU' ) $country = 'Russian Federation';
    if( $code == 'RW' ) $country = 'Rwanda';
    if( $code == 'BL' ) $country = 'Saint Barthelemy';
    if( $code == 'SH' ) $country = 'Saint Helena';
    if( $code == 'KN' ) $country = 'Saint Kitts and Nevis';
    if( $code == 'LC' ) $country = 'Saint Lucia';
    if( $code == 'MF' ) $country = 'Saint Martin';
    if( $code == 'PM' ) $country = 'Saint Pierre and Miquelon';
    if( $code == 'VC' ) $country = 'Saint Vincent and the Grenadines';
    if( $code == 'WS' ) $country = 'Samoa';
    if( $code == 'SM' ) $country = 'San Marino';
    if( $code == 'ST' ) $country = 'Sao Tome and Principe';
    if( $code == 'SA' ) $country = 'Saudi Arabia';
    if( $code == 'SN' ) $country = 'Senegal';
    if( $code == 'RS' ) $country = 'Serbia';
    if( $code == 'SC' ) $country = 'Seychelles';
    if( $code == 'SL' ) $country = 'Sierra Leone';
    if( $code == 'SG' ) $country = 'Singapore';
    if( $code == 'SK' ) $country = 'Slovakia (Slovak Republic)';
    if( $code == 'SI' ) $country = 'Slovenia';
    if( $code == 'SB' ) $country = 'Solomon Islands';
    if( $code == 'SO' ) $country = 'Somalia, Somali Republic';
    if( $code == 'ZA' ) $country = 'South Africa';
    if( $code == 'GS' ) $country = 'South Georgia and the South Sandwich Islands';
    if( $code == 'ES' ) $country = 'Spain';
    if( $code == 'LK' ) $country = 'Sri Lanka';
    if( $code == 'SD' ) $country = 'Sudan';
    if( $code == 'SR' ) $country = 'Suriname';
    if( $code == 'SJ' ) $country = 'Svalbard & Jan Mayen Islands';
    if( $code == 'SZ' ) $country = 'Swaziland';
    if( $code == 'SE' ) $country = 'Sweden';
    if( $code == 'CH' ) $country = 'Switzerland, Swiss Confederation';
    if( $code == 'SY' ) $country = 'Syrian Arab Republic';
    if( $code == 'TW' ) $country = 'Taiwan';
    if( $code == 'TJ' ) $country = 'Tajikistan';
    if( $code == 'TZ' ) $country = 'Tanzania';
    if( $code == 'TH' ) $country = 'Thailand';
    if( $code == 'TL' ) $country = 'Timor-Leste';
    if( $code == 'TG' ) $country = 'Togo';
    if( $code == 'TK' ) $country = 'Tokelau';
    if( $code == 'TO' ) $country = 'Tonga';
    if( $code == 'TT' ) $country = 'Trinidad and Tobago';
    if( $code == 'TN' ) $country = 'Tunisia';
    if( $code == 'TR' ) $country = 'Turkey';
    if( $code == 'TM' ) $country = 'Turkmenistan';
    if( $code == 'TC' ) $country = 'Turks and Caicos Islands';
    if( $code == 'TV' ) $country = 'Tuvalu';
    if( $code == 'UG' ) $country = 'Uganda';
    if( $code == 'UA' ) $country = 'Ukraine';
    if( $code == 'AE' ) $country = 'United Arab Emirates';
    if( $code == 'GB' ) $country = 'United Kingdom';
    if( $code == 'US' ) $country = 'United States of America';
    if( $code == 'UM' ) $country = 'United States Minor Outlying Islands';
    if( $code == 'VI' ) $country = 'United States Virgin Islands';
    if( $code == 'UY' ) $country = 'Uruguay, Eastern Republic of';
    if( $code == 'UZ' ) $country = 'Uzbekistan';
    if( $code == 'VU' ) $country = 'Vanuatu';
    if( $code == 'VE' ) $country = 'Venezuela';
    if( $code == 'VN' ) $country = 'Vietnam';
    if( $code == 'WF' ) $country = 'Wallis and Futuna';
    if( $code == 'EH' ) $country = 'Western Sahara';
    if( $code == 'YE' ) $country = 'Yemen';
    if( $code == 'ZM' ) $country = 'Zambia';
    if( $code == 'ZW' ) $country = 'Zimbabwe';
    if( $country == '') $country = $code;
    return $country;
}
?>