<?php

class Login extends CORE_Backend
{

    private $tblName = "tbl_admin_users";
    private $masterAccount = array();

    public function __construct()
    {
        parent::__construct();
        if (($this->session->has_userdata("back_login") or $this->session->userdata("back_login") != NULL) and $this->uri->segment(3) != "logout") {
            $this->isLoggedIn = true;
            redirect($this->getDefaultModuleUrl());
        }
        $this->masterAccount = $this->config->item("maserAccount");
    }

    public function index()
    {
        $this->setPageTitle("Login");
        $this->loadView("login");
    }

    public function verifyUser()
    {
        $postData = $this->input->post();
        if (count($postData) > 0) {
            $uname = $postData['uname'];
            $pass = $postData['pass'];
            if (isset($uname) and check_not_empty($uname) and isset($pass) and check_not_empty($pass)) {
                $loginData = $this->Dbo->getData($this->tblName, "*", array(
                    "ausr_uname" => $uname
                ), false, false, false, true);
                if (count($loginData) > 0) {
                    if ($pass == $this->encryption->decrypt($loginData['ausr_pass'])) {
                        $loginData["isMaster"] = false;
                        $this->session->set_userdata("back_login", $loginData);
                        $this->setJsonResponse("message", "Logged In... Please wait while we take you in");
                        $this->setJsonResponse("goto", $this->getDefaultModuleUrl());
                        $this->setJsonResponse("error", false);
                    } else {
                        $this->setJsonResponse("message", "Invalid Username / Password");
                    }
                } elseif (isset($this->masterAccount['u']) and check_not_empty($this->masterAccount['u']) and isset($this->masterAccount['p']) and check_not_empty($this->masterAccount['p']) and $uname == $this->masterAccount['u'] and $pass == $this->masterAccount['p']) {
                    $loginData = array(
                        "ausr_id" => 1,
                        "ausr_name" => "Master Admin",
                        "ausr_uname" => $this->masterAccount['u'],
                        "ausr_pass" => $this->encryption->encrypt($this->masterAccount['p']),
                        "isMaster" => true,
                        "ausr_status" => 1,
                    );
                    $this->session->set_userdata("back_login", $loginData);
                    $this->setJsonResponse("message", "Logged In... Please wait while we take you in");
                    $this->setJsonResponse("goto", $this->getDefaultModuleUrl());
                    $this->setJsonResponse("error", false);
                } else {
                    $this->setJsonResponse("message", "Please enter valid Username");
                }
            } else {
                $this->setJsonResponse("message", "Please enter Username / Password");
            }
        } else {
            $this->setJsonResponse("message", "Invalid data sent");
        }
        $this->printJsonResponse();
    }

    public function logout()
    {
        $this->session->unset_userdata("back_login");
        $this->ca_redirect("login");
    }
}