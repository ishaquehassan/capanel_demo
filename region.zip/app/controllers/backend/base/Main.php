<?php

class Main extends CORE_Backend{

    public function __construct()
    {
        parent::__construct();
    }

    public function installRefresh(){
        if(file_exists(__DIR__."/../../../config/temp_configs.".$this->panelName)){
            unlink(__DIR__."/../../../config/temp_configs.".$this->panelName);
            redirect(base_url($this->panelName));
        }
    }
}