<?php

/**
 * Created by PhpStorm.
 * User: Talha Khan
 * Date: 6/1/2016
 * Time: 11:04 AM
 */
class ModuleDefault extends CORE_Mhandler
{

    public function __construct()
    {
        parent::__construct();
    }

    public function index()
    {
        $this->loadCurrentView();
    }

    public function manage()
    {
        $this->loadCurrentView();
    }

    public function add()
    {
        $this->setViewParam("frmAction", $this->getCtrlUrls("add", true));
        $this->setFeaturePageTitle("Add");
        $this->loadCurrentView();
    }

    public function edit($id = false)
    {
        if (!$id) {
            $this->redirectToDefault();
            die();
        }
        $this->setViewParam("frmAction", $this->getCtrlUrls("edit", true));
        $this->setFeaturePageTitle("Edit");
        $this->setViewParam("editData", $this->Dbo->getData($this->getDbTable(), "*", array(
            $this->getDbPrefix("id") => $id
        ), false, false, false, true));
        $this->loadCurrentView();
    }

    public function create()
    {
        $this->processPostPrefix();
        $postData = $this->getPostData();
        $this->Dbo->saveData($this->getDbTable(), $postData);
        $this->redirectToDefault();
    }

    public function update()
    {
        $this->processPostPrefix();
        $id = $this->getPostData()[$this->getDbPrefix("id")];
        $postData = $this->getPostData();
        $this->Dbo->saveData($this->getDbTable(), $postData, array(
            $this->getDbPrefix("id") => $id
        ));
        $this->redirectToDefault();
    }

    public function delete($id = false)
    {
        if ($id) {
            $curData = $this->Dbo->getData($this->getDbTable(), "*", array(
                $this->getDbPrefix("id") => $id
            ), false, false, false, true);
            if (count($curData) > 0) {
                $del = $this->Dbo->delData($this->getDbTable(), array(
                    $this->getDbPrefix("id") => $id
                ));
                if ($del) {
                    $this->setJsonResponse("message", "Deleted Successfully!");
                    $this->setJsonResponse("error", false);
                } else {
                    $this->setJsonResponse("message", "There was an error while deleting your record!");
                }
            } else {
                $this->setJsonResponse("message", "Data not exists!");
            }
        } else {
            $this->setJsonResponse("message", "Invalid Parameters!");
        }
        $this->printJsonResponse();
    }

    public function dataTableSource()
    {
        $cols = array(
            array(
                "dt" => 0,
                "db" => $this->getDbPrefix("id")
            ),
            array(
                "dt" => 1,
                "db" => $this->getDbPrefix("title")
            ),
            array(
                "dt" => 2,
                "db" => $this->getDbPrefix("value"),
                "formatter" =>  function ($data, $row) {
                    $data = substr($data,0,75);
                    if($row[$this->getDbPrefix("type")] != "rich-text"){
                        return $data;
                    }else{
                        return (check_not_empty($data) ? "<strong><a href='".$this->getUiUrls("edit", true)."/".$row[$this->getDbPrefix("id")]."' >".$row[$this->getDbPrefix("title")]."</a></strong>" : "N/A");
                    }
                }
            ),
            array(
                "dt" => 3,
                "db" => $this->getDbPrefix("id"),
                "formatter" =>  function ($data, $row) {
                    $r = '<a href="' . $this->getUiUrls("edit", true) . "/" . $data . '"><i class="fa fa-pencil-square-o" aria-hidden="true"></i></a>';
                    return $r;
                }
            )
        );

        $this->initDataTable($cols, $this->getDbPrefix("status")." > 0",array($this->getDbPrefix("type")));
        echo $this->getDataTableResult();
    }
}