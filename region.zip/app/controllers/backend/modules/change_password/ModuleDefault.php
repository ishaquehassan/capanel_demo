<?php

/**
 * Created by PhpStorm.
 * User: Talha Khan
 * Date: 6/1/2016
 * Time: 11:04 AM
 */
class ModuleDefault extends CORE_Mhandler
{

    public function __construct()
    {
        parent::__construct();
    }

    public function index(){

    }

    public function change()
    {
        $this->setViewParam("frmAction", $this->getCtrlUrls("add", true));
        $this->loadCurrentView();
    }

    public function update()
    {
        $id = $this->session->back_login['ausr_id'];

        $this->check_form->set_rules(
            "currentPassword",
            'Current Password',
            'trim|required|min_length[5]|max_length[100]|callback_checkCurrentPass'
        );

        $this->check_form->set_rules("newPassword", 'New Password', 'trim|required|min_length[5]|max_length[100]');
        $this->check_form->set_rules("rnewPassword", 'Confirm New Password', 'trim|required|matches[newPassword]');


        if ($this->check_form->run() == FALSE) {
            $this->setViewParam("frmAction", $this->getCtrlUrls("add", true));
            $this->loadView($this->getUiUrls("change"));
        }else{
            $this->processPostPrefix();
            $postData = $this->getPostData();
            $pass = $this->encryption->encrypt($postData[$this->getDbPrefix("newPassword")]);

            $save = $this->Dbo->saveData($this->db_table, array(
                $this->getDbPrefix("pass") => $pass
            ), array(
                $this->getDbPrefix("id") => $id
            ));

            if ($save) {
                $this->setJsonResponse('msg',"Saved");
                $this->setJsonResponse('error',false);
                $this->sendJsonSession();
            } else {
                $this->setJsonResponse('msg',"Error While Saving");
                $this->sendJsonSession();

            }
            $this->redirectToDefault();
        }
    }

    public function checkCurrentPass($str){
        if(check_not_empty($str)){
            $id = $this->session->back_login['ausr_id'];
            $changePass = $this->Dbo->getData($this->getDbTable(),$this->getDbPrefix("pass")." pass",array(
                $this->getDbPrefix("id") => $id
            ),false,false,false,true);

            $curPass = $this->encryption->decrypt($changePass['pass']);
            $chk = ($str == $curPass);

            if(!$chk){
                $this->check_form->set_message("checkCurrentPass","Current Password is incorrect");
                return false;
            }else{
                return true;
            }
        }else{
            $this->check_form->set_message("checkCurrentPass","Please enter Current Password");
        }
    }
}