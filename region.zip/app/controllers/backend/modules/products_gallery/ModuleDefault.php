<?php

/**
 * Created by PhpStorm.
 * User: Talha Khan
 * Date: 6/1/2016
 * Time: 11:04 AM
 */
class ModuleDefault extends CORE_Mhandler
{
    public function __construct()
    {
        parent::__construct();
        $this->removeBreadCrumb();
        if(isset($this->getModule()->parent_module)){
            $this->initialize($this->getModule()->parent_module);
            $this->initialize(false,false);
            $this->addBreadCrumb($this->getModule()->title,$this->buildQstrUrl($this->getModuleUrl()));
        }
    }

    public function index()
    {
        $this->loadCurrentView();
    }

    public function manage()
    {
        $this->setViewParam("gridData", $this->Dbo->getData($this->getDbTable(), "*", false, false, $this->getDbPrefix() . "id DESC"));
        $this->loadCurrentView();
    }

    public function add()
    {
        $this->setViewParam("frmAction", $this->buildQstrUrl($this->getCtrlUrls("add", true)));
        $this->setFeaturePageTitle("Add");
        $this->loadCurrentView();
    }

    public function edit($id = false)
    {
        if (!$id) {
            $this->redirectToDefault();
            die();
        }
        $this->setViewParam("frmAction", $this->buildQstrUrl($this->getCtrlUrls("edit", true)));
        $this->setFeaturePageTitle("Edit");
        $this->setViewParam("editData", $this->Dbo->getData($this->getDbTable(), "*", array(
            $this->getDbPrefix("id") => $id
        ), false, false, false, true));
        $this->loadCurrentView();
    }

    public function create()
    {
        $this->processPostPrefix();
        $gimgs = array();
        $ff = 0;
        foreach ($_FILES[$this->getDbPrefix() . "image"] as $name => $value){
            foreach ($value as $k =>$v){
                $gimgs["image_".$k][$name] = $v;
            }
            $ff++;
        }
        $postData = $this->getPostData();
        $c = 0;
        foreach ($gimgs as $k => $gimg){
            $_FILES[$k] = $gimg;
            $upload = $this->uploadFile($k, $this->getUploadDir());
            if (!$upload["error"]){
                $postData[$this->getDbPrefix() . "image"] = $upload['uploadData']["file_name"];
                $postData[$this->getDbPrefix() . "main"] = 0;
                if($c === 0){
                    if(count($this->Dbo->getData($this->getDbTable(),$this->getDbPrefix() . "main",array($this->getDbPrefix("prdId") => $_GET['cat']))) <= 0){
                        $postData[$this->getDbPrefix() . "main"] = 1;
                    }
                    $c++;
                }
            }
            $this->Dbo->saveData($this->getDbTable(), $postData);
        }
        $this->redirectToDefault();
    }

    public function update()
    {
        $this->processPostPrefix();
        $id = $this->getPostData()[$this->getDbPrefix("id")];
        $upload = $this->uploadFile($this->getDbPrefix() . "image", $this->getUploadDir());
        $curData = $this->Dbo->getData($this->getDbTable(), "*", array(
            $this->getDbPrefix("id") => $id
        ), false, false, false, true);
        $postData = $this->getPostData();
        if (!$upload["error"]) {
            $postData[$this->getDbPrefix() . "image"] = $upload['uploadData']["file_name"];
            if (file_exists($this->getUploadDir() . $curData[$this->getDbPrefix("image")])) {
                unlink($this->getUploadDir() . $curData[$this->getDbPrefix("image")]);
            }
        }
        $this->Dbo->saveData($this->getDbTable(), $postData, array(
            $this->getDbPrefix("id") => $id
        ));
        $this->redirectToDefault();
    }

    public function delete($id = false)
    {
        if ($id) {
            $curData = $this->Dbo->getData($this->getDbTable(), "*", array(
                $this->getDbPrefix("id") => $id
            ), false, false, false, true);
            if (count($curData) > 0) {
                $del = $this->Dbo->delData($this->getDbTable(), array(
                    $this->getDbPrefix("id") => $id
                ));
                if ($del) {
                    if (file_exists($this->getUploadDir() . $curData[$this->getDbPrefix("image")])) {
                        unlink($this->getUploadDir() . $curData[$this->getDbPrefix("image")]);
                    }
                    $this->setJsonResponse("message", "Deleted Successfully!");
                    $this->setJsonResponse("error", false);
                } else {
                    $this->setJsonResponse("message", "There was an error while deleting your record!");
                }
            } else {
                $this->setJsonResponse("message", "Data not exists!");
            }
        } else {
            $this->setJsonResponse("message", "Invalid Parameters!");
        }
        $this->printJsonResponse();
    }

    public function updateMain($id = false)
    {
        if ($id) {
            $curData = $this->Dbo->getData($this->getDbTable(), "*", array(
                $this->getDbPrefix("id") => $id
            ), false, false, false, true);
            if (count($curData) > 0) {
                $update = $this->Dbo->saveData($this->getDbTable(), array(
                    $this->getDbPrefix("main") => 1
                ), array(
                    $this->getDbPrefix("id") => $id,
                    $this->getDbPrefix("prdId") => $_GET['cat']
                ));
                if ($update) {
                    $this->Dbo->saveData($this->getDbTable(), array(
                        $this->getDbPrefix("main") => 0
                    ), array(
                        $this->getDbPrefix("id")." !=" => $id,
                        $this->getDbPrefix("prdId") => $_GET['cat']
                    ));
                    $this->setJsonResponse("message", "Success");
                    $this->setJsonResponse("error", false);
                } else {
                    $this->setJsonResponse("message", "There was an error while changing status!");
                }
            } else {
                $this->setJsonResponse("message", "Data not exists!");
            }
        } else {
            $this->setJsonResponse("message", "Invalid Parameters!");
        }
        $this->printJsonResponse();
    }

    public function dataTableSource()
    {
        $cols = array(
            array(
                "dt" => 0,
                "db" => $this->getDbPrefix("id")
            ),
            array(
                "dt" => 1,
                "db" => $this->getDbPrefix("image"),
                "formatter" =>  function ($data, $row) {
                    $r = ((check_not_empty($data) and file_exists($this->getUploadDir() . $data)) ? '<a href="' . $this->getUploadDir(true) . $data . '" class="light-box text-center"><i class="fa fa-picture-o" aria-hidden="true"></i></a>' : "-");
                    return $r;
                }
            ),
            array(
                "dt" => 2,
                "db" => $this->getDbPrefix("image"),
                "formatter" =>  function ($data, $row) {
                    $r = ((check_not_empty($data) and file_exists($this->getUploadDir() . $data)) ? '<a href="' . $this->getUploadDir(true) . $data . '" class="light-box text-center"><i class="fa fa-picture-o" aria-hidden="true"></i></a>' : "-");
                    return $r;
                }
            ),array(
                "dt" => 3,
                "db" => $this->getDbPrefix("main"),
                "formatter" =>  function ($data, $row) {
                    $r = '<input type="checkbox" switch-button data-action="' . $this->buildQstrUrl($this->getCtrlUrls("main", true). "/" . $row[0])  . '" class="main_toggle_btn" ' . ($data > 0 ? "checked disabled" : "") . ' />';
                    return $r;
                }
            ),array(
                "dt" => 4,
                "db" => $this->getDbPrefix("status"),
                "formatter" =>  function ($data, $row) {
                    $r = '<input type="checkbox" switch-button data-action="' . $this->getCtrlUrls("status", true) . "/" . $row[0] . '" class="status_btn" ' . ($data > 0 ? "checked" : "") . ' />';
                    return $r;
                }
            ),array(
                "dt" => 5,
                "db" => $this->getDbPrefix("id"),
                "formatter" =>  function ($data, $row) {
                    $r = '<a href="' . $this->buildQstrUrl($this->getUiUrls("edit", true) . "/" . $data) . '" class="text-center"><i class="fa fa-pencil-square-o" aria-hidden="true"></i></a>';
                    return $r;
                }
            ),array(
                "dt" => 6,
                "db" => $this->getDbPrefix("id"),
                "formatter" =>  function ($data, $row) {
                    $durl = "'" . $this->getCtrlUrls("delete", true) . "/" . $data . "'";
                    $r = '<a href="#" onclick="deleteGrid(' . $durl . ',this)" class="text-center"><i class="fa fa-trash-o" aria-hidden="true"></i></a>';
                    return $r;
                }
            ),
        );

        $this->initDataTable($cols,$this->getDbPrefix("prdId")." = ".$_GET['cat']);
        echo $this->getDataTableResult();
    }
}