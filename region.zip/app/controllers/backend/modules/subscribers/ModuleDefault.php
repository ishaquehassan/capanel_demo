<?php

/**
 * Created by PhpStorm.
 * User: Talha Khan
 * Date: 6/1/2016
 * Time: 11:04 AM
 */
class ModuleDefault extends CORE_Mhandler
{

    public function __construct()
    {
        parent::__construct();
    }

    public function index()
    {
        $this->loadCurrentView();
    }

    public function exportCustomers(){
        $customers = $this->Dbo->getData($this->getDbTable(),"*",array(
            "sub_email !=" => ""
        ),"sub_email");

        if(count($customers) > 0){

            $filename = "SUBSCRIBERS LIST.xls";

            header("Content-Disposition: attachment; filename=\"$filename\"");
            header("Content-Type: application/vnd.ms-excel");

            $html = '<html xmlns:x="urn:schemas-microsoft-com:office:excel">

<head>

    <xml>

        <x:ExcelWorkbook>

            <x:ExcelWorksheets>

                <x:ExcelWorksheet>

                    <x:Name>Hania Kamran Emails Data</x:Name>

                    <x:WorksheetOptions>

                        <x:Print>

                            <x:ValidPrinterInfo/>

                        </x:Print>

                    </x:WorksheetOptions>

                </x:ExcelWorksheet>

            </x:ExcelWorksheets>

        </x:ExcelWorkbook>

    </xml>

    <![endif]-->

</head>



<body>';


            $html .= '<table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tr>';

            $html .= '<td style="font-weight:bold;">Email</td>';

            $html .= '</tr>';




            foreach($customers as $customer){
                $html .= "<tr>";
                $html .= "<td>";
                $html .= $customer['sub_email'];
                $html .= "</td>";
                $html .= "</tr>";
            }

            $html .= '</table>';
            echo $html;

            $this->setJsonResponse("msg","Data exported");
        }else{
            $this->setJsonResponse("msg","There is no data to export");
        }
        $this->sendJsonSession();
    }
}