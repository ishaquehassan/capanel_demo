<?php
class CORE_Mhandler extends CORE_Backend
{
    private $moduleName = "";
    private $module;
    private $viewName;
    private $dataTable;
    private $dbInfo = array();
    private $dataTableColumns = array();
    private $dataTableWhere = false;
    private $dataTableExtraFields = array();
    private $dataTableJoin = array();
    private $dataTableGroup = "";

    public function __construct()
    {
        parent::__construct();
        $this->moduleName = $this->uri->segment(3);
        $this->viewType = $this->viewType . '/modules/' . $this->moduleName;
        $this->dbInfo = $this->config->item('db_info');
        $this->initialize();
        if (check_not_empty($this->uri->segment(4))) {
            $this->viewName = $this->uri->segment(4);
        } else {
            $uiArray = (Array)$this->getUiUrls();
            $this->viewName = current(array_keys($uiArray));
            redirect($this->getUiUrls($this->viewName, true));
        }
    }

    public function initialize($module = false,$addBreadCrumb = true)
    {
        if (!$module) {
            $moduleName = $this->moduleName;
        } else {
            $moduleName = $module;
        }
        if ($this->getModuleObject($moduleName)) {
            $this->module = $this->getModuleObject($moduleName);
            $this->Dbo->setTableName($this->getDbConfig()->table);
            $this->setPageTitle($this->getModule()->title,false);
            if($addBreadCrumb){
                $this->addBreadCrumb(false,$this->getModuleUrl());
            }
        } else {

        }
    }

    public function getDbConfig()
    {
        return $this->getModule()->db_config;
    }

    public function getModule()
    {
        return $this->module;
    }


    public function getModuleInstance($module = false){
        $r = null;
        $this->initialize($module,false);
        $r = serialize($this);
        $this->initialize(false,false);
        return unserialize($r);
    }

    public function getUiUrls($uiName = false, $buildLink = false)
    {
        $uis = $this->getModule()->urls->ui;
        if (!$uiName) {
            return $uis;
        } else {
            $uis = (Array)$uis;
            return ($buildLink ? $this->module_base_url($uis[$uiName]) : $uis[$uiName]);
        }
    }

    public function module_base_url($url = false)
    {
        return $this->base_url(($url ? "module/" . $this->moduleName . "/" . $url : "module/" . $this->moduleName));
    }

    public function getQstr($inArray = false){
        $getStr = "";
        if(count($_GET) > 0){
            foreach ($_GET as $k => $v){
                if(is_array($v)){
                    $v = urlencode(serialize($v));
                }
                $getStr[] = $k."=".$v;
            }
            $getStr = implode("&",$getStr);
        }
        return $getStr;
    }

    public function buildQstrUrl($url = ""){
        return $url."/?".$this->getQstr();
    }

    public function getUploadDir($view = false)
    {
        if (!$view) {
            return "assets/uploads/" . $this->getModule()->upload_dir;
        } else {
            return "../uploads/" . $this->getModule()->upload_dir;
        }

    }

    public function getCtrlUrls($ctrlName = false, $buildLink = false)
    {
        $ctrls = $this->getModule()->urls->ctrls;
        if (!$ctrlName) {
            return $ctrls;
        } else {
            $ctrls = (Array)$ctrls;
            return ($buildLink ? $this->module_base_url($ctrls[$ctrlName]) : $ctrls[$ctrlName]);
        }
    }

    public function loadCurrentView()
    {
        $this->loadView($this->getViewName());
    }

    /**
     * @param mixed $viewName
     */
    public function setViewName($viewName)
    {
        $this->viewName = $viewName;
    }

    public function getViewName()
    {
        $name = $this->viewName;
        return $this->getUiUrls()->$name;
    }

    public function loadBtmJs($specificPageVendor = "btmJs.php")
    {
        $this->loadView("btmJs", "backend/tpl");
        if ($specificPageVendor != false) {
            $this->loadView("tpl/" . $specificPageVendor);
        }
        $this->loadView("jsInits", "backend/tpl");
    }

    public function processPostPrefix()
    {
        foreach ($this->getPostData() as $k => $v) {
            $_POST[$this->getDbConfig()->prefix . $k] = $v;
            unset($_POST[$k]);
        }
        foreach ($this->getPostFilesData() as $k => $v) {
            $_FILES[$this->getDbConfig()->prefix . $k] = $v;
            unset($_FILES[$k]);
        }
    }

    public function redirectToDefault()
    {
        $uiArray = (Array)$this->getUiUrls();
        $this->viewName = current(array_keys($uiArray));
        redirect($this->buildQstrUrl($this->getUiUrls($this->viewName, true)));
    }

    public function updateStatus($id = false,$field = "status")
    {
        if ($id) {
            $curData = $this->Dbo->getData($this->getDbTable(), "*", array(
                $this->getDbPrefix("id") => $id
            ), false, false, false, true);
            if (count($curData) > 0) {
                $newStatus = ($curData[$this->getDbPrefix($field)] > 0 ? 0 : 1);
                $update = $this->Dbo->saveData($this->getDbTable(), array(
                    $this->getDbPrefix($field) => $newStatus
                ), array(
                    $this->getDbPrefix("id") => $id
                ));
                if ($update) {
                    $this->setJsonResponse("message", ($newStatus > 0 ? "Enabled" : "Disabled") . " Successfully!");
                    $this->setJsonResponse("error", false);
                } else {
                    $this->setJsonResponse("message", "There was an error!");
                }
            } else {
                $this->setJsonResponse("message", "Data not exists!");
            }
        } else {
            $this->setJsonResponse("message", "Invalid Parameters!");
        }
        $this->printJsonResponse();
    }

    public function updatePublic($id = false)
    {
        if ($id) {
            $curData = $this->Dbo->getData($this->getDbTable(), "*", array(
                $this->getDbPrefix("id") => $id
            ), false, false, false, true);
            if (count($curData) > 0) {
                $newStatus = ($curData[$this->getDbPrefix("public")] > 0 ? 0 : 1);
                $update = $this->Dbo->saveData($this->getDbTable(), array(
                    $this->getDbPrefix("public") => $newStatus
                ), array(
                    $this->getDbPrefix("id") => $id
                ));
                if ($update) {
                    $this->setJsonResponse("message", ($newStatus > 0 ? "Enabled" : "Disabled") . " Successfully!");
                    $this->setJsonResponse("error", false);
                } else {
                    $this->setJsonResponse("message", "There was an error while changing status!");
                }
            } else {
                $this->setJsonResponse("message", "Data not exists!");
            }
        } else {
            $this->setJsonResponse("message", "Invalid Parameters!");
        }
        $this->printJsonResponse();
    }

    public function getDbTable()
    {
        return $this->getDbConfig()->table;
    }

    public function getDbPrefix($fieldName = false)
    {
        if (!$fieldName) {
            return $this->getDbConfig()->prefix;
        } else {
            return $this->getDbConfig()->prefix . $fieldName;
        }
    }

    public function initDataTable($cols = array(), $where = false, $extraFields = array(),$join = false,$groupBy = false)
    {
        $this->load->library("datatables");
        $this->dataTable = new Datatables();
        $this->dataTableColumns = $cols;
        //$this->processDataTableCols();
        $this->dataTableWhere = $where;
        $this->dataTableExtraFields = $extraFields;
        $this->dataTableJoin = $join;
        if($groupBy and check_not_empty($groupBy)){
            $this->dataTableGroup = "GROUP BY ".$groupBy;
        }else{
            $this->dataTableGroup = $groupBy;
        }
    }

    public function getDataTableResult()
    {
        $sql_details = array(
            'user' => $this->dbInfo['username'],
            'pass' => $this->dbInfo['password'],
            'db' => $this->dbInfo['database'],
            'host' => $this->dbInfo['hostname']
        );

        return json_encode(
            $this->getDataTable()->simple($_GET, $sql_details, $this->getDbTable(), $this->getDbPrefix("id"), $this->dataTableColumns, $this->dataTableWhere, $this->dataTableExtraFields,$this->dataTableJoin,$this->dataTableGroup),
            JSON_UNESCAPED_UNICODE
        );
    }

    public function getDataTable()
    {
        return $this->dataTable;
    }


    public function get_slug($tbl,$fieldName,$title,$id=false){
        $slug_temp = Slug($title);
        $whr = array($fieldName => $slug_temp);
        $slug = "";
        if($id !== false){
            $whr[$id[0]." !="] = $id[1];
        }

        $sl_check = $this->Dbo->getData($tbl,$fieldName,$whr,false,false,false,true);
        if(count($sl_check) > 0){
            $ok = 0;
            $si = 1;
            while($ok == 0){
                $this_slug = $slug_temp."-".$si;
                $whr[$fieldName] = $this_slug;
                $siw_q = $this->Dbo->getData($tbl,$fieldName,$whr,false,false,false,true);
                if(count($siw_q) == 0){
                    $slug = Slug($this_slug);
                    $ok = 1;
                    break;
                }else{
                    $si++;
                }
            }

        }else{
            $slug = Slug($title);
        }
        return $slug;
    }

    public function getModuleUrl(){
        $uiArr = ((Array)$this->getUiUrls());
        return base_url($this->panelName.'/module/'.$this->getModule()->package."/".$uiArr[array_keys((Array)$this->getUiUrls())[0]]);
    }

    public function setFeaturePageTitle($title = false,$addBreadCrumb = true){
        if($title){
            $this->setPageTitle($this->getPageTitle()." > ".$title);
            if($addBreadCrumb){
                $this->removeBreadCrumb();
                $this->addBreadCrumb($title,$this->getCurrentUrl());
            }
        }
    }

    protected function buildAliases($fields = array()){
        $contentInfo = $this->getDbConfig();
        $prefix = $contentInfo->prefix;
        $table = $contentInfo->table;
        $final_fields = array();
        foreach ($fields as $field){
            $actual = $field;
            $alias = $field;
            if(is_array($field)){
                $actual = array_keys($field)[0];
                $alias = $field[$actual];
            }
            $final_fields[] = $table.".".$prefix.$actual." ".$alias;
        }
        return implode(",",$final_fields);
    }
}