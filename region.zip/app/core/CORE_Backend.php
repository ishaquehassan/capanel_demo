<?php

class CORE_Backend extends CORE_Base{

    private $defaultModule = null;
    public $isLoggedIn = false;
    public $vzBreadcrumbs = array();
    private $pageTitle = "";

    public function __construct()
    {
        $this->viewType = 'backend';
        parent::__construct();
        if(!$this->session->has_userdata("back_login") or $this->session->userdata("back_login") == NULL ){
            if(check_not_empty($this->uri->segment(2)) and $this->uri->segment(2) != "login"){
                $this->isLoggedIn = false;
                $this->ca_redirect("login");
            }
        }
        $this->check_form->set_error_delimiters('<p class="error">', '</p>');
    }

    public function getDefaultModule(){
        foreach ($this->modules_config as $module){
            if(isset($module->isDefault) and $module->isDefault){
                $this->defaultModule = $module;
                break;
            }
        }

        return $this->defaultModule;
    }

    public function getDefaultModuleUrl(){
        return $this->base_url("module/".$this->getDefaultModule()->package);
    }

    public function ca_redirect($url = ""){
        redirect(base_url($this->panelName."/".$url));
    }

    public function base_url($url = false){
        return base_url(($url ? $this->panelName."/".$url : ""));
    }

    public function getPageTitle()
    {
        return $this->pageTitle;
    }

    public function setPageTitle($pageName = "",$addBreadCrumb = true)
    {
        $this->pageTitle = $pageName;
        if($addBreadCrumb){
            $this->addBreadCrumb();
        }
        parent::setPageTitle($pageName);
    }

    public function addBreadCrumb($name = false,$link = false){
        if(!$name){
            $name = $this->pageTitle;
        }

        if(!$link){
            $link = $this->getCurrentUrl();
        }

        $this->vzBreadcrumbs[] = array("name" => $name,"link" => $link);
    }

    public function removeBreadCrumb($index = false){
        $indexToRemove = (!$index ? (count($this->vzBreadcrumbs) - 1) : $index);
        if(count($this->vzBreadcrumbs) and isset($this->vzBreadcrumbs[$indexToRemove])){
            unset($this->vzBreadcrumbs[$indexToRemove]);
            $this->vzBreadcrumbs = array_values($this->vzBreadcrumbs);
        }
    }

    public function loadView($viewName = false, $path = false)
    {
        $this->setViewParam("breadcrumbs",$this->vzBreadcrumbs);
        parent::loadView($viewName, $path);
    }
}