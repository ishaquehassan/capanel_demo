<?php
/**
 * Created by PhpStorm.
 * User: Ishaq Hassan
 * Date: 12/31/2016
 * Time: 2:16 PM
 */

class CORE_Api extends CORE_FrontendBase{
    public function __construct()
    {
        parent::__construct();
        /*$headers = apache_request_headers();
        if(!isset($headers['username']) or $headers['username'] !== "admin" or !isset($headers['password']) or $headers['password'] !== "admin"){
            $this->setJsonResponse("error",true);
            $this->setJsonResponse("msg","Authentication Error");
            $this->printJsonResponse();
            die();
        }*/
    }

    protected function buildAliases($moduleName,$fields = array()){
        $contentInfo = $this->getModuleConfig($moduleName, "db_config");
        $prefix = $contentInfo->prefix;
        $table = $contentInfo->table;
        $final_fields = array();
        foreach ($fields as $field){
            $actual = $field;
            $alias = $field;
            if(is_array($field)){
                $actual = array_keys($field)[0];
                $alias = $field[$actual];
            }
            $final_fields[] = $table.".".$prefix.$actual." ".$alias;
        }
        return implode(",",$final_fields);
    }

    public function setData($data = array()){
        if(count($data) <= 0){
            $this->setJsonResponse("error",true);
            if(!check_not_empty($this->getJsonResponse("message"))){
                $this->setJsonResponse("message","Data not found");
            }
        }else{
            $this->setJsonResponse("error",false);
            if(!check_not_empty($this->getJsonResponse("message"))){
                $this->setJsonResponse("message","Data not found");
            }
        }
        $this->setJsonResponse("data",$data);
    }

    public function __destruct()
    {
        $this->printJsonResponse();
    }
}