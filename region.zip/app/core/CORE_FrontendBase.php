<?php

class CORE_FrontendBase extends CORE_Base
{
    public $breadcrumbs = array();
    public $currencySymbol = "";
    private $pageTitle = "";
    private $meta_data = array();

    public function __construct()
    {
        parent::__construct();
        //Navigation Contents
    }

    public function getModuleConfig($moduleName = false, $subIndex = false)
    {
        if ($moduleName) {
            if (!$subIndex) {
                return $this->getModuleObject($moduleName);
            } else {
                return $this->getModuleObject($moduleName)->$subIndex;
            }
        }
    }

    public function setPageTitle($pageName = "")
    {
        $this->pageTitle = $pageName;
        $this->addBreadCrumb();
        $this->setViewParam("pageTitle", (check_not_empty($pageName) ? $pageName . " - " : "") . $this->getViewParam("settings")[1]);
        $this->setViewParam("pageName", $pageName);
    }

    public function addBreadCrumb($name = false, $link = false)
    {
        if (!$name) {
            $name = $this->pageTitle;
        }
        if (!$link) {
            $link = $this->getCurrentUrl();
        }
        $this->breadcrumbs[] = array("name" => $name, "link" => $link);
    }

    public function getUploadsDir($moduleName = false, $frontEnd = false)
    {
        if (!$frontEnd) {
            return "assets/uploads/" . $this->getModuleConfig($moduleName, "upload_dir");
        } else {
            return "../uploads/" . $this->getModuleConfig($moduleName, "upload_dir");
        }
    }

    public function loadView($viewName = false, $path = false)
    {
        $this->setViewParam("breadcrumbs", $this->breadcrumbs);
        $this->setViewParam("meta_data",$this->meta_data);
        parent::loadView($viewName, $path);
        //$this->output->cache(0.15);
    }

    public function getMetaData()
    {
        return $this->meta_data;
    }

    public function addMetaData($property = "",$content = "")
    {
        $this->meta_data[$property] = $content;
    }
}