/**
 * Created by HP on 12/12/2016.
 */
$(document).ready(function () {
    $('.main-banner').slick(
        {
            dots: true,
            autoplay: true
        }
    );

    $('.products-carousel-slick').slick(
        {
            slidesToShow: 4,
            autoplay: true,
            responsive: [
                {
                    breakpoint: 600,
                    settings: {
                        slidesToShow: 1,
                        slidesToScroll: 1
                    }
                }
            ]
        }
    );

    $('.clients-carousel').slick(
        {
            slidesToShow: 6,
            autoplay: true,
            responsive: [
                {
                    breakpoint: 600,
                    settings: {
                        slidesToShow: 2,
                        slidesToScroll: 2
                    }
                }
            ]
        }
    );

    $('.product-detail').magnificPopup({
        type:'inline',
        midClick: true
    });

});

function notify(msg, type) {
    var notyDiv = $(".notification");
    if ($(notyDiv).hasClass("open")) {
        $(notyDiv).removeClass("open");
    }

    $(notyDiv).click(function (e) {
        e.preventDefault();
        $(notyDiv).removeClass("open");
        setTimeout(function () {
            $(notyDiv).children("p").html("");
        }, 500);
    });

    $(notyDiv).children("p").html(msg);
    $(notyDiv).addClass(type);

    $(notyDiv).addClass("open");
    setTimeout(function () {
        $(notyDiv).removeClass("open");
        setTimeout(function () {
            $(notyDiv).children("p").html("");
        }, 500);
    }, 10000);

}