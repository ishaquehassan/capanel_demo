<!DOCTYPE html>
<html lang="en">
<head>
    <?php include "tpl/head.php"; ?>
</head>
<body>
<div class="master-container">
    <?php include "tpl/header.php"; ?>
    <div class="main-banner">
        <a href="#">
            <img src="images/demo1_02.png" align=""/>
        </a>
    </div>
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <h3>Products</h3>

                <div class="row products-list-container">

                    <div class="col-lg-3 products-list-side-bar">
                        <div class="module">
                            <h3 class="module-title">Categories</h3>
                            <nav>
                                <ul style="margin-top: 15px">
                                    <?php foreach ($categories as $category) {
                                        $scats = $base_class->Dbo->getData($productsView, "*", array(
                                            $subCategoriesInfo->prefix . "catId" => $category['cat_id']
                                        ), $subCategoriesInfo->prefix . "id");
                                        ?>
                                        <li>
                                            <a href="<?= base_url('products/' . $category['cat_id']) ?>">
                                                <?= $category["cat_title"] ?>
                                            </a>
                                            <?php if (count($scats) > 0) { ?>
                                                <ul>
                                                    <?php foreach ($scats as $scat) { ?>
                                                        <li>
                                                            <a href="<?= base_url('products/' . $category['cat_id'] . '/' . $scat['scat_id']) ?>">
                                                                <?= $scat["scat_title"] ?>
                                                            </a>
                                                        </li>
                                                    <?php } ?>
                                                </ul>
                                            <?php } ?>
                                        </li>
                                    <?php } ?>
                                </ul>
                            </nav>
                        </div>
                    </div>


                    <div class="col-lg-9 products-list">
                        <div class="row list-item">
                            <?php
                            $colCount = 1;
                            $phoneCount = 1;
                            foreach ($products as $product) { ?>
                                <?php if (file_exists($base_class->getUploadsDir("products") . $product['prd_image'])) { ?>
                                    <div class="col-lg-4 col-sm- col-xs-6" style="padding: 0px !important;">
                                        <div>
                                            <div class="col-md-12 item-img-col">
                                                <img
                                                    src="<?= $base_class->getUploadsDir("products", true) . $product['prd_image'] ?>"
                                                    alt="" class="img-responsive item-img">
                                            </div>
                                            <div class="col-md-12 item-details">
                                                <h4 class="text-center"><?= $product['prd_title'] ?></h4>
                                                <div style="clear:both;"></div>
                                                <a class="btn btn-borders btn-primary mt-lg center-block product-detail"
                                                   href="#product-detail-<?=$product['prd_id']?>">Details</a>


                                                <div id="product-detail-<?=$product['prd_id']?>" class="row list-item white-popup mfp-hide">
                                                    <div class="col-md-6 item-img-col">
                                                        <img src="<?= $base_class->getUploadsDir("products", true) . $product['prd_image']?>" alt="" class="img-responsive item-img">
                                                    </div>
                                                    <div class="col-md-6 item-details">
                                                        <h4><?=$product['prd_title']?></h4>
                                                        <div style="clear:both;"></div>
                                                        <p>
                                                            <?=str_2_p($product['prd_descp'])?>
                                                        </p>
                                                        <div style="clear:both;"></div>
                                                    </div>
                                                </div>


                                            </div>
                                        </div>
                                    </div>

                                    <?php if ($phoneCount == 2) { ?>
                                        <div class="clear-fix hidden-lg hidden-md"></div>
                                    <?php $phoneCount = 0;} ?>
                                    <?php if ($colCount == 3) { ?>
                                        <div class="clear-fix hidden-xs hidden-sm"></div>
                                        <?php $colCount = 0;
                                    } ?>
                                    <?php $colCount++;$phoneCount++;
                                } ?>
                            <?php } ?>

                        </div>
                    </div>

                    <!--<div class="col-lg-9 products-list">
                        <?php /*foreach ($products as $product) { */ ?>
                            <?php /*if (file_exists($base_class->getUploadsDir("products") . $product['prd_image'])) { */ ?>
                                <div class="row list-item">
                                    <div class="col-md-3 item-img-col">
                                        <img src="<? /*= $base_class->getUploadsDir("products", true) . $product['prd_image'] */ ?>" alt="" class="img-responsive item-img">
                                    </div>
                                    <div class="col-md-7 item-details">
                                        <h4><? /*= $product['prd_title'] */ ?></h4>
                                        <div style="clear:both;"></div>
                                        <p>
                                            <? /*=str_2_p($product['prd_descp'])*/ ?>
                                        </p>
                                        <div style="clear:both;"></div>
                                        <a class="btn btn-borders btn-primary mt-lg" href="#">Get a Quote</a>
                                    </div>
                                </div>
                            <?php /*} */ ?>
                        <?php /*} */ ?>
                    </div>-->
                </div>
            </div>
        </div>
    </div>
    <?php include "tpl/footer.php"; ?>
</div>
</body>
</html>