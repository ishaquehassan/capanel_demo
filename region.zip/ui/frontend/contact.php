<!DOCTYPE html>
<html lang="en">
<head>
    <?php include "tpl/head.php"; ?>
</head>
<body>
<div class="master-container">
    <?php include "tpl/header.php"; ?>
    <?php include "tpl/banners.php"; ?>
    <div class="container">
        <div class="row">
            <div class="col-md-4">
                <div class="row">
                    <div class="s30"></div>
                    <?php if(check_not_empty($settings[8])){ ?>
                        <div class="col-xs-12 col-sm-12 col-md-12">
                            <div class="icon-box text-left media bg-deep p-30 mb-20">
                                <a class="media-left pull-left" href="#"> <i
                                        class="text-theme-colored fa fa-map-marker"></i></a>
                                <div class="media-body"><strong>ADDRESS</strong>
                                    <p><?=str_2_p($settings[8])?></p>
                                </div>
                            </div>
                        </div>
                    <?php } ?>
                    <?php if(check_not_empty($settings[9])){ ?>
                        <div class="col-xs-12 col-sm-6 col-md-12">
                            <div class="icon-box left media bg-deep p-30 mb-20">
                                <a class="media-left pull-left" href="#">
                                    <i class="text-theme-colored fa fa-phone"></i> </a>
                                <div class="media-body"><strong>CONTACT NUMBER</strong>
                                    <p><?=$settings[9]?></p>
                                </div>
                            </div>
                        </div>
                    <?php } ?>
                    <?php if(check_not_empty($settings[15])){ ?>
                        <div class="col-xs-12 col-sm-6 col-md-12">
                            <div class="icon-box left media bg-deep p-30 mb-20">
                                <a class="media-left pull-left" href="#">
                                    <i class="text-theme-colored fa fa-phone"></i> </a>
                                <div class="media-body"><strong>TOLL FREE</strong>
                                    <p><?=$settings[15]?></p>
                                </div>
                            </div>
                        </div>
                    <?php } ?>
                    <?php if(check_not_empty($settings[13])){ ?>
                        <div class="col-xs-12 col-sm-6 col-md-12">
                            <div class="icon-box left media bg-deep p-30 mb-20">
                                <a class="media-left pull-left" href="#">
                                    <i class="text-theme-colored fa fa-fax"></i> </a>
                                <div class="media-body"><strong>FAX NUMBER</strong>
                                    <p><?=$settings[13]?></p>
                                </div>
                            </div>
                        </div>
                    <?php } ?>
                    <?php if(check_not_empty($settings[10])){ ?>
                        <div class="col-xs-12 col-sm-6 col-md-12">
                            <div class="icon-box left media bg-deep p-30 mb-20">
                                <a class="media-left pull-left" href="#">
                                    <i class="text-theme-colored fa fa-envelope"></i> </a>
                                <div class="media-body"><strong>CONTACT E-MAIL</strong>
                                    <p><a href="mailto:<?=$settings[10]?>"><?=$settings[10]?></a></p>
                                </div>
                            </div>
                        </div>
                    <?php } ?>
                </div>
            </div>

            <div class="col-md-8">
                <h3 class="mt-0 mb-30">Interested in discussing?</h3>
                <!-- Contact Form -->
                <form id="contact_form" name="contact_form" class="" action="<?=base_url('send-contact')?>" method="post" novalidate="novalidate">

                    <div class="row">
                        <div class="col-sm-6">
                            <div class="form-group">
                                <label for="form_name">Name <small>*</small></label>
                                <input id="cnt_fullname" name="name" class="cform-control" type="text" placeholder="Enter Name"  required="" aria-required="true">
                            </div>
                        </div>
                        <div class="col-sm-6">
                            <div class="form-group">
                                <label for="form_email">Email <small>*</small></label>
                                <input id="cnt_email" name="email" class="cform-control required email" type="email" required placeholder="Enter Email" aria-required="true">
                            </div>
                        </div>
                    </div>

                    <div class="row">
                        <div class="col-sm-6">
                            <div class="form-group">
                                <label for="form_name">Subject <small>*</small></label>
                                <input id="cnt_subject" name="subject" class="cform-control required" type="text" required placeholder="Enter Subject" aria-required="true">
                            </div>
                        </div>
                        <div class="col-sm-6">
                            <div class="form-group">
                                <label for="form_phone">Phone <small>*</small></label>
                                <input id="cnt_phone" name="phone" class="cform-control" type="text" required placeholder="Enter Phone">
                            </div>
                        </div>
                    </div>

                    <div class="form-group">
                        <label for="form_name">Message <small>*</small></label>
                        <textarea id="cnt_message" name="message" class="cform-control required" required rows="5" placeholder="Enter Message" aria-required="true"></textarea>
                    </div>
                    <div class="form-group">
                        <input id="form_botcheck" name="form_botcheck" class="form-control" type="hidden" value="">
                        <button type="submit" class="btn btn-theme btn-theme-color mr-5" data-loading-text="Please wait...">Send </button>
                        <button type="reset" class="btn btn-theme btn-theme-color">Reset</button>
                    </div>
                </form>


            </div>
        </div>
        <?php if(check_not_empty($settings[11])){ ?>
            <div class="clearfix"></div>
            <br/>
            <div class="map mt-30">
                <h4>How To Reach Us</h4>
                <iframe
                    src="<?=$settings[11]?>" frameborder="0" style="border:0; width:100%; min-height:400px;" allowfullscreen=""></iframe>
            </div>
        <?php } ?>
    </div>
    <?php include "tpl/footer.php"; ?>
    <script>

        $(document).ready(function (e) {
            $("#contact_form").submit(function (e) {
                e.preventDefault();
                $(".frm_stat").text("Please wait...!");
                var frm = $(this);
                frm.find("input,textarea").attr("readonly", true);
                $.ajax({
                    url: frm.attr("action"),
                    method: 'POST',
                    data: frm.serializeArray(),
                    dataType: 'json',
                    success: function (r) {
                        if (!r.error) {
                            notify(r.msg);
                            frm.find("input,textarea").removeAttr("readonly");
                            frm.find("input:not([type='submit']),textarea").val("");
                        } else {
                            notify(r.msg,"error");
                        }
                    }
                });
            });
        });

    </script>
</div>
</body>
</html>