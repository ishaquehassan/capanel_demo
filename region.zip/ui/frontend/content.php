<!DOCTYPE html>
<html lang="en">
<head>
    <?php include "tpl/head.php"; ?>
</head>
<body>
<div class="master-container">
    <?php include "tpl/header.php"; ?>
    <?php include "tpl/banners.php"; ?>
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <h3><?= $contentPageData['cnt_title'] ?></h3>
                <div class="cnt_descp">
                    <?= $contentPageData['cnt_descp'] ?>
                </div>
            </div>
        </div>
    </div>
    <?php include "tpl/footer.php"; ?>
</div>
</body>
</html>