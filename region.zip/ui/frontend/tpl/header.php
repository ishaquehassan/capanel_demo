<div class="hidden-xs"><?php include 'top-bar.php' ?></div>
<header>
    <div class="container">
        <div class="row">
            <div class="pull-left logo-container">
                <a href="#" id="mobile-menu-toggle" onclick="$('.nav-container').toggleClass('open')">
                    <span></span>
                    <span></span>
                    <span></span>
                </a>
                <a class="logo" href="#"><img class="img-responsive " src="images/logo.png"/></a>
            </div>
            <div class="nav-container pull-right">
                <nav>
                    <ul>
                        <li>
                            <a href="<?=base_url('home')?>">Home</a>
                        </li>
                        <li>
                            <a href="<?=base_url('company')?>">Company</a>
                            <!--<ul>
                                <li>
                                    <a href="#">Dropdown Option 1</a>
                                </li>
                                <li>
                                    <a href="#">Dropdown Option 2</a>
                                </li>
                                <li>
                                    <a href="#">Dropdown Option 3</a>
                                </li>
                            </ul>-->
                        </li>
                        <li>
                            <a href="<?=base_url('products')?>">Products</a>
                        </li>
                        <li>
                            <a href="<?=base_url('contact')?>">Contact Us</a>
                        </li>
                    </ul>
                    <div class="visible-xs"><?php include 'top-bar.php' ?></div>
                </nav>
            </div>
        </div>
    </div>
</header>
<div class="visible-xs responsive-spacer"></div>