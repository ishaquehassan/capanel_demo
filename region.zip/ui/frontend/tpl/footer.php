<footer>
    <div class="container">
        <div class="row">
            <div class="col-md-3 footer-col footer-col-address">
                <img src="images/logo.png" alt="" class="img-responsive"/>
                <?php if(check_not_empty($settings[8])){ ?>
                <p><i style="position: absolute;margin-top: 6px;" class="fa fa-map-marker pull-left" aria-hidden="true"></i>
                    <span class="pull-left" style="padding-left: 20px;"><?=str_2_p($settings[8])?></span></p>
                <?php } ?>
            </div>
            <div class="col-md-2 footer-col">
                <h4>Web Contents</h4>
                <ul>
                    <li>
                        <a href="<?= base_url('home') ?>">
                            home
                        </a>
                    </li>
                    <li>
                        <a href="<?= base_url('company') ?>">
                            Company
                        </a>
                    </li>

                </ul>
            </div>
            <div class="col-md-2 footer-col">
                <h4>&nbsp;</h4>
                <ul>
                    <li>
                        <a href="<?= base_url('products') ?>">
                            Products
                        </a>
                    </li>
                    <li>
                        <a href="<?= base_url('contact') ?>">
                            Contact
                        </a>
                    </li>
                </ul>
            </div>
            <div class="col-md-5 footer-col">
                <h4>Newsletter</h4>
                <form action="<?=base_url('subscribe')?>" method="post" class="newsletter-form">
                    <input type="email" name="email" value="" placeholder="Email Address" required/>
                    <button type="submit" name="submit"><i class="fa fa-paper-plane-o" aria-hidden="true"></i>
                    </button>
                </form>
                <div class="contact-details">
                    <div class="row">
                        <div class="col-lg-12">
                            <?php if(check_not_empty($settings[8])){ ?>
                                <i class="fa fa-map-marker" style="height: 40px;float: left;clear: right;display: block;margin-top: 4px;margin-right: 7px;" aria-hidden="true"></i>
                                <span><?=str_2_p($settings[8])?></span>
                            <?php } ?>
                        </div>
                    </div>
                    <?php if (check_not_empty($settings[9])) { ?>
                        <div class="pull-left">
                            <i class="fa fa-phone" aria-hidden="true"></i>
                            <span>
                                <a href="tel:<?= $settings[9] ?>"><?= $settings[9] ?></a>
                            </span>
                        </div>
                    <?php } ?>
                    <?php if (check_not_empty($settings[10])) { ?>
                        <div class="pull-left">
                            <i class="fa fa-envelope" aria-hidden="true"></i>
                            <span>
                                <a href="mailto:i<?= $settings[10] ?>"><?= $settings[10] ?></a>
                            </span>
                        </div>
                    <?php } ?>
                </div>
            </div>
        </div>
        <div class="row copy-right">
            <div class="col-lg-12">
                <p class="text-center" style="margin: 0;">Copyright &copy;<?= date('Y') ?>. All Rights Reserved.
                    Developed By <a href="http://cyberavanza.com" target="_blank">Cyber Avanza</a></p>
            </div>
        </div>
    </div>
</footer>
<div class="notification">
    <p class="text"></p>
</div>
<script>
    $(document).ready(function () {
        $(".newsletter-form").submit(function (e) {
            e.preventDefault();
            var frm = $(this);
            var data = frm.serializeArray();
            var acion = frm.attr("action");
            var method = frm.attr("method");

            $.ajax({
                url: acion,
                type: method,
                data: data,
                dataType: 'json',
                success: function (res) {
                    notify(res.msg, (res.error ? "error" : false));
                    if (!res.error) {
                        $(frm).get(0).reset();
                    }
                }, error: function (e) {
                    console.log(e);
                }
            });
        });

        $("a[href='#']").click(function (e) {
           e.preventDefault();
        });
    });
</script>