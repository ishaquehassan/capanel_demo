<div class="top-bar">
    <div class="container">
        <div class="row">
            <div class="pull-left">
                <?php if(check_not_empty($settings[17])){ ?>
                <a href="<?=$settings[17]?>" target="_blank">
                    <i class="fa fa-facebook-square" aria-hidden="true"></i>
                </a>
                <?php } ?>
                <?php if(check_not_empty($settings[18])){ ?>
                <a href="<?=$settings[18]?>" target="_blank">
                    <i class="fa fa-twitter-square" aria-hidden="true"></i>
                </a>
                <?php } ?>
                <?php if(check_not_empty($settings[16])){ ?>
                <a href="<?=$settings[16]?>" target="_blank">
                    <i class="fa fa-google-plus-square" aria-hidden="true"></i>
                </a>
                <?php } ?>
            </div>
            <div class="pull-right contact-bar">
                <div class="pull-right">
                    <?php if(check_not_empty($settings[8])){ ?>
                        <a>
                            <i class="fa fa-map-marker" aria-hidden="true"></i>
                            <span><?=$settings[8]?></span>
                        </a>
                    <?php } ?>
                    <?php if(check_not_empty($settings[10])){ ?>
                        <a href="mailto:<?=$settings[10]?>">
                            <i class="fa fa-envelope" aria-hidden="true"></i>
                            <span><?=$settings[10]?></span>
                        </a>
                    <?php } ?>
                    <?php if(check_not_empty($settings[9])){ ?>
                        <a href="tel:<?=$settings[9]?>">
                            <i class="fa fa-phone" aria-hidden="true"></i>
                            <span><?=$settings[9]?></span>
                        </a>
                    <?php } ?>
                </div>
            </div>
        </div>
    </div>
</div>