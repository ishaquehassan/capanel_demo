<div class="main-banner">
    <?php foreach ($banners as $c => $banner) { ?>
        <?php if (file_exists($base_class->getUploadsDir("banners") . $banner['ban_image'])) { ?>
            <a <?= (check_not_empty($banner['ban_link']) ? 'href="' . $banner['ban_link'] . '"' : "") ?>>
                <img src="<?= $base_class->getUploadsDir("banners", true) . $banner['ban_image'] ?>" alt=""
                     data-lazyload="<?= $base_class->getUploadsDir("banners", true) . $banner['ban_image'] ?>"
                     data-bgposition="center top"
                     data-bgfit="cover" data-bgrepeat="no-repeat">
            </a>
        <?php } ?>
    <?php } ?>
</div>