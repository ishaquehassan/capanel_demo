<BASE href="<?=base_url('assets/frontend/')?>/" />
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">
<title><?=$pageTitle?></title>
<link href="css/bootstrap.min.css" rel="stylesheet"/>
<link href="css/bootstrap-theme.min.css" rel="stylesheet"/>
<link href="css/styles.css?v=<?= uniqid() ?>" rel="stylesheet"/>
<link rel="stylesheet" href="plugins/magnific-popup/magnific-popup.css">
<script src="https://use.fontawesome.com/95ee64c2f2.js"></script>
<script src="js/jquery-1.9.1.min.js"></script>
<script src="plugins/magnific-popup/jquery.magnific-popup.js"></script>
<script src="plugins/slick/slick.min.js"></script>
<script src="js/app.js?v=<?= uniqid() ?>"></script>