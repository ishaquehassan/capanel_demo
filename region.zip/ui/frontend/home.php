<!DOCTYPE html>
<html lang="en">
<head>
    <?php include "tpl/head.php"; ?>
</head>
<body>
<div class="master-container">
    <?php include "tpl/header.php"; ?>

    <?php include "tpl/banners.php"; ?>

    <div class="service-highlight-blocks home-section">
        <div class="container">
            <div class="row">
                <div class="col-md-3 col-xs-6 service">
                    <div class="img-holder">
                        <div class="markers">
                            <img src="images/s3.jpg" alt=""/>
                            <img src="images/s3_h.jpg" alt=""/>
                        </div>
                    </div>
                    <div class="details">
                        <h4>Hydrant</h4>
                        <p>Lorem ipsum dolor sit amet, consectetur adipiscing</p>
                    </div>
                    <a class="fa fa-play-circle read-more-btn" href="#"></a>
                </div>
                <div class="col-md-3 col-xs-6 service">
                    <div class="img-holder">
                        <div class="markers">
                            <img src="images/s4.jpg" alt=""/>
                            <img src="images/s4_h.jpg" alt=""/>
                        </div>
                    </div>
                    <div class="details">
                        <h4>H Beam</h4>
                        <p>Lorem ipsum dolor sit amet, consectetur adipiscing</p>
                    </div>
                    <a class="fa fa-play-circle read-more-btn" href="#"></a>
                </div>
                <div class="col-md-3 col-xs-6 service">
                    <div class="img-holder">
                        <div class="markers">
                            <img src="images/s1.jpg" alt=""/>
                            <img src="images/s1_h.jpg" alt=""/>
                        </div>
                    </div>
                    <div class="details">
                        <h4>Hex Nuts</h4>
                        <p>Lorem ipsum dolor sit amet, consectetur adipiscing</p>
                    </div>
                    <a class="fa fa-play-circle read-more-btn" href="#"></a>
                </div>
                <div class="col-md-3 col-xs-6 service">
                    <div class="img-holder">
                        <div class="markers">
                            <img src="images/s2.jpg" alt=""/>
                            <img src="images/s2_h.jpg" alt=""/>
                        </div>
                    </div>
                    <div class="details">
                        <h4>Tee Plumbing</h4>
                        <p>Lorem ipsum dolor sit amet, consectetur adipiscing</p>
                    </div>
                    <a class="fa fa-play-circle read-more-btn" href="#"></a>
                </div>
            </div>
        </div>
    </div>
    <?php if (count($products) > 0) { ?>
        <div class="products-carousel home-section">
            <div class="container">
                <div class="row">
                    <h3 class="heading-1">OUR PRODUCTS</h3>
                </div>
                <div class="row products-carousel-slick">
                    <?php foreach ($products as $product) { ?>
                        <?php if (file_exists($base_class->getUploadsDir("products") . $product['prd_image'])) { ?>
                            <div>
                                <div class="carousel-item">
                                    <img src="<?= $base_class->getUploadsDir("products", true) . $product['prd_image'] ?>" class="img-responsive" alt="">
                                    <div class="details">
                                        <h4><?=$product['prd_title']?></h4>
                                        <a class="fa fa-arrow-circle-o-right" href="<?=base_url('products')?>"></a>
                                    </div>
                                </div>
                            </div>
                        <?php } ?>
                    <?php } ?>
                </div>
                <div class="center-block">
                    <a class="btn-custom-1" href="#">
                        View All Products
                    </a>
                </div>
            </div>
        </div>
    <?php } ?>
    <div class="clients home-section">
        <div class="container">
            <div class="row">
                <h3 class="heading-1">OUR CLIENTS</h3>
            </div>
            <div class="clients-carousel">
                <?php foreach ($partners as $c => $client) { ?>
                    <?php if (file_exists($base_class->getUploadsDir("clients") . $client['cli_image'])) { ?>
                        <a href="#">
                            <img src="<?= $base_class->getUploadsDir("clients", true) . $client['cli_image'] ?>"
                                 class="img-responsive" alt=""/>
                        </a>
                    <?php } ?>
                <?php } ?>
            </div>
        </div>
    </div>
    <?php include "tpl/footer.php"; ?>
</div>
</body>
</html>