<header class="header">
    <div class="logo-container">
        <a href="../" class="logo">
            <img src="images/logo.png" height="35" alt="Porto Admin"/>
        </a>

        <div class="visible-xs toggle-sidebar-left" data-toggle-class="sidebar-left-opened" data-target="html"
             data-fire-event="sidebar-left-opened">
            <i class="fa fa-bars" aria-label="Toggle sidebar"></i>
        </div>
    </div>

    <!-- start: search & user box -->
    <div class="header-right">


        <span class="separator" style="visibility: hidden;"></span>

        <div id="userbox" class="userbox">
            <a href="#" data-toggle="dropdown">
                <figure class="profile-picture">
                    <img src="images/!logged-user.jpg" alt="Joseph Doe" class="img-circle"
                         data-lock-picture="images/!logged-user.jpg"/>
                </figure>
                <div class="profile-info" data-lock-name="John Doe" data-lock-email="johndoe@okler.com">
                    <span class="name"><?= $settings[1] ?> Administrator</span>
                    <span class="role">Options</span>
                </div>

                <i class="fa custom-caret"></i>
            </a>

            <div class="dropdown-menu">
                <ul class="list-unstyled">
                    <li class="divider"></li>
                    <li><a role="menuitem" tabindex="-1"
                           href="<?=base_url($base_class->panelName.'/module/settings')?>"><i
                                class="fa fa-cogs"></i> Settings</a></li>
                    <li><a role="menuitem" tabindex="-1" href="<?=base_url($base_class->panelName.'/login/logout')?>"><i
                                class="fa fa-power-off"></i> Logout</a></li>
                    <li><a role="menuitem" tabindex="-1" href="<?=base_url()?>" target="_blank"> <i class="fa fa-eye"></i> View Site</a></li>
                    <li><a role="menuitem" tabindex="-1" href="<?=base_url($base_class->panelName.'/module/subscribers/exportCustomers')?>"> <i class="fa fa-download"></i> Download Subscribers</a></li>
                    <?php if(ENVIRONMENT  == "development"){ ?>
                    <li><a role="menuitem" tabindex="-1" href="<?=base_url($base_class->panelName.'/build')?>"> <i class="fa fa-refresh"></i> Rebuild Project</a></li>
                    <?php } ?>
                </ul>
            </div>
        </div>
    </div>
    <!-- end: search & user box -->
</header>