<script src="vendor/jquery/jquery.js"></script>
<script src="vendor/jquery-browser-mobile/jquery.browser.mobile.js"></script>
<script src="vendor/bootstrap/js/bootstrap.js"></script>
<script src="vendor/nanoscroller/nanoscroller.js"></script>
<script src="vendor/bootstrap-datepicker/js/bootstrap-datepicker.js"></script>
<script src="vendor/magnific-popup/magnific-popup.js"></script>
<script src="vendor/jquery-placeholder/jquery.placeholder.js"></script>

<script src="vendor/bootstrap-fileupload/bootstrap-fileupload.min.js"></script>

<script src="vendor/select2/select2.js"></script>
<script src="vendor/jquery-datatables/media/js/jquery.dataTables.js"></script>
<script src="vendor/jquery-datatables/extras/TableTools/js/dataTables.tableTools.min.js"></script>
<script src="vendor/jquery-datatables-bs3/assets/js/datatables.js"></script>
<script src="vendor/pnotify/pnotify.custom.js"></script>
<script src="vendor/switch-button/switch.js"></script>
<script src="vendor/jquery-datatables/pipeline.js"></script>

<script src="javascripts/custom/backend.js"></script>
<?php
if (isset($jsonResponse) and check_not_empty($jsonResponse['msg'])) {
    ?>
    <script>
        $(document).ready(function (e) {

            var msgtype = "<?=($jsonResponse['error'] ? 'error' : 'success')?>";
            new PNotify({
                title: "<?=$jsonResponse['msg']?>",
                type: msgtype
            });

        });
    </script>
<?php } ?>

