<header class="page-header">
    <h2><?=$base_class->getModule()->title?></h2>

    <div class="right-wrapper pull-right" style="margin-right: 20px;">
        <ol class="breadcrumbs">
            <!--<li>
                <a href="index.html">
                    <i class="<?/*=$base_class->getModule()->icon*/?>"></i>
                    <span><?/*=$base_class->getModule()->title*/?></span>
                </a>
            </li>-->
            <?php foreach($breadcrumbs as $breadcrumb){ ?>
                <li><a title="" href="<?=$breadcrumb['link']?>" class="home"><?=$breadcrumb['name']?></a></li>
            <?php } ?>
        </ol>
    </div>
</header>
<style>
    .obx{
        width: 30px;
        min-width: initial !important;
        margin-right: 10px;
        padding: 2px 10px !important;
        height: auto !important;
        text-align: center;

    }
</style