<aside id="sidebar-left" class="sidebar-left">

    <div class="sidebar-header">
        <div class="sidebar-title">
            Navigation
        </div>
        <div class="sidebar-toggle hidden-xs" data-toggle-class="sidebar-left-collapsed" data-target="html"
             data-fire-event="sidebar-left-toggle">
            <i class="fa fa-bars" aria-label="Toggle sidebar"></i>
        </div>
    </div>


    <div class="nano">
        <div class="nano-content">
            <nav id="menu" class="nav-main" role="navigation">
                <ul class="nav nav-main">
                    <?php foreach ($base_class->modules_config as $module) { ?>
                        <?php if (!isset($module->navHidden) or !$module->navHidden) {
                            $isMe = $module->package == $base_class->getModule()->package;
                            if(!$isMe and isset($module->child_modules) and count($module->child_modules) > 0){
                                foreach($module->child_modules as $child_module){
                                    if($base_class->getModule()->package == $child_module->package){
                                        $isMe = true;
                                    }
                                }
                            }
                            ?>
                            <li class="<?= ($isMe ? "nav-active" : "") ?>">
                                <a href="<?= $base_class->base_url("module/" . $module->package) ?>">
                                    <i class="<?= $module->icon ?>" aria-hidden="true"></i>
                                    <span><?= $module->title ?></span>
                                </a>
                            </li>
                        <?php } ?>
                    <?php } ?>
                </ul>
            </nav>
        </div>
    </div>

</aside>