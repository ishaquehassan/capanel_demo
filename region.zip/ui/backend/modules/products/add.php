<!doctype html>
<html class="<?php include __DIR__ . '/../../tpl/themeName.php'; ?>">
<head>
    <?php include __DIR__ . '/../../tpl/head.php'; ?>
</head>
<body>
<section class="body">

    <!-- start: header -->
    <?php include __DIR__ . '/../../tpl/header.php'; ?>
    <!-- end: header -->

    <div class="inner-wrapper">
        <!-- start: sidebar -->
        <?php include __DIR__ . '/../../tpl/nav.php'; ?>
        <!-- end: sidebar -->
        <section role="main" class="content-body">
            <?php include __DIR__ . '/../../tpl/page-header.php'; ?>

            <!-- start: page -->
            <div class="row">
                <div class="col-lg-12">
                    <section class="panel">
                        <header class="panel-heading">
                            <h2 class="panel-title">Add <?= $base_class->getModule()->title ?></h2>
                        </header>
                        <div class="panel-body">
                            <form class="form-horizontal form-bordered" action="<?=$frmAction?>" method="post" enctype="multipart/form-data">
                                <div class="form-group">
                                    <label class="col-md-3 control-label" for="">Title</label>

                                    <div class="col-md-6">
                                        <input type="text" name="title" required class="form-control" />
                                    </div>
                                </div>

                                <div class="form-group">
                                    <label class="col-md-3 control-label" for="catId">Category</label>

                                    <div class="col-md-6">
                                        <select data-plugin-selectTwo class="form-control" required name="catId" title="">
                                            <option value="">Select Category</option>
                                            <?php foreach ($categories as $category) { ?>
                                                <option
                                                    value="<?= $category['id'] ?>"><?= $category['title'] ?></option>
                                            <?php } ?>
                                        </select>
                                    </div>
                                </div>


                                <div class="form-group clesBox" style="display: none;">
                                    <label class="col-md-3 control-label" for="scatId">Sub Category</label>

                                    <div class="col-md-6">
                                        <select data-plugin-selectTwo class="form-control" required name="scatId" title="">
                                            <option value="">Select Sub Category</option>
                                        </select>
                                    </div>
                                </div>


                                <div class="form-group">
                                    <label class="col-md-3 control-label" for="">Image</label>
                                    <div class="col-md-6">
                                        <input type="file" name="image" required class="form-control" />
                                    </div>
                                </div>

                                <div class="form-group">
                                    <label class="col-md-3 control-label" for="">Description</label>
                                    <div class="col-md-6">
                                        <textarea class="form-control" name="descp" rows="6"></textarea>
                                    </div>
                                    <div class="col-md-3">
                                        <p><input type="text" class="form-control pull-left obx" readonly value="&bull;"> Bullets</p>
                                    </div>
                                </div>


                                <div class="form-group">
                                    <div class="col-md-2 pull-left col-md-offset-3">
                                        <button type="reset" class="mb-xs mt-xs mr-xs btn btn-default">Reset</button>
                                        <button type="submit" class="mb-xs mt-xs mr-xs btn btn-primary">Save</button>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </section>

                </div>
            </div>
            <!-- end: page -->
        </section>
    </div>
</section>

<?= $base_class->loadBtmJs() ?>
<!-- Examples -->
<script>
    $(document).ready(function (e) {
        var clesBoxDefaultHtml = $(".clesBox").find("option:nth-child(1) ~ option").remove().html();
        $("select[name='catId']").on("change", function (e) {
            var cat = $(this).val();
            var clesBox = $(".clesBox");
            var sel = clesBox.find("select");

            $.ajax({
                url: "<?=$getSubCats?>",
                type: "POST",
                data: {
                    cat: cat
                }, dataType: "json",
                success: function (data) {
                    if (data.scats.length > 0) {
                        sel.select2('destroy');
                        sel.css("width","100%");
                        sel.html(clesBoxDefaultHtml);
                        sel.find("option").remove();
                        $.each(data.scats, function (key, data) {
                            sel.append('<option value="'+data.value+'">'+data.name+'</option>');
                        });

                        sel.select2({
                            theme:"bootstrap"
                        });

                        clesBox.slideDown('fast');
                    }else {
                        if(clesBox.is(":visible")){
                            clesBox.slideUp('fast');
                        }
                        sel.html(clesBoxDefaultHtml);
                    }
                }, error: function (e) {
                    //console.log(e);
                }
            });
        });
    });
</script>
</body>
</html>