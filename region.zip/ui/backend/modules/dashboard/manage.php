<!doctype html>
<html class="<?php include __DIR__ . '/../../tpl/themeName.php'; ?>">
<head>
    <?php include __DIR__ . '/../../tpl/head.php'; ?>
</head>
<body>
<section class="body">

    <!-- start: header -->
    <?php include __DIR__ . '/../../tpl/header.php'; ?>
    <!-- end: header -->

    <div class="inner-wrapper">
        <!-- start: sidebar -->
        <?php include __DIR__ . '/../../tpl/nav.php'; ?>
        <!-- end: sidebar -->
        <section role="main" class="content-body">
            <?php include __DIR__ . '/../../tpl/page-header.php'; ?>
            <!-- start: page -->
            <div class="row" style="display: none;">
                <div class="col-md-6 col-lg-12 col-xl-6">
                    <section class="panel">
                        <div class="panel-body">
                            <div class="row">
                                <div class="col-lg-12">
                                    <a href="<?=base_url($base_class->panelName."/module/subscribers/exportCustomers")?>" class="btn btn-primary">Download Subscribers</a>
                                </div>
                                <div class="col-lg-6 col-md-12">
                                    <section class="panel panel-transparent">
                                        <header class="panel-heading">
                                            <h2 class="panel-title">Global Stats</h2>
                                        </header>
                                        <div class="panel-body">
                                            <div id="vectorMapWorld" style="height: 350px; width: 100%;"></div>
                                        </div>
                                    </section>
                                </div>
                                <div class="col-md-6">
                                    <section class="panel panel-transparent">
                                        <header class="panel-heading">
                                            <h2 class="panel-title">Server Usage</h2>
                                        </header>
                                        <div class="panel-body">
                                            <!-- Flot: Curves -->
                                            <div class="chart chart-md" id="flotDashRealTime"></div>
                                        </div>
                                    </section>
                                </div>
                            </div>
                        </div>
                    </section>
                </div>
            </div>

            <!-- end: page -->
        </section>
    </div>
</section>

<?= $base_class->loadBtmJs() ?>
<!-- Examples -->
<script src="javascripts/dashboard/examples.dashboard.js"></script>
</body>
</html>